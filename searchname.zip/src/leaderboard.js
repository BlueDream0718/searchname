


const initialData =
{
  "00D1LA8puAa1GINkVpfgC1TmO0m1" : {
    "bananas" : 200,
    "lastDayPlayed" : "2018-11-22",
    "longestStreak" : 1,
    "name" : "Rica Ella Francisco",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "00D1LA8puAa1GINkVpfgC1TmO0m1"
  },
  "x8RNvUgv5pZqDVatEXb2aYgSflq1" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Adh Fuoo",
    "stars" : 4,
    "subscribed" : false,
    "uid" : "x8RNvUgv5pZqDVatEXb2aYgSflq1"
  },
  
  "ylL3XqPOlycHiPBuf1uXHlgZzEr2" : {
    "bananas" : 150,
    "lastDayPlayed" : "2018-10-17",
    "longestStreak" : 1,
    "name" : "Jayne Su YueHe",
    "stars" : 4,
    "subscribed" : false,
    "uid" : "ylL3XqPOlycHiPBuf1uXHlgZzEr2"
  },
  "ylsPzJdfKggHuBVcqHVYxzVRdtJ2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Yo Yo Chou",
    "stars" : 4,
    "subscribed" : false,
    "uid" : "ylsPzJdfKggHuBVcqHVYxzVRdtJ2"
  },
  "ylwtBuIr70fEIxcCE80fSRRo7np2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Toke Chen",
    "stars" : 4,
    "subscribed" : false,
    "uid" : "ylwtBuIr70fEIxcCE80fSRRo7np2"
  },
  "ymAf3Zs3MCe0zwjQnATm2B9LmeY2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "王連辟",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "ymAf3Zs3MCe0zwjQnATm2B9LmeY2"
  },
  "ymXlQBolGjc664PfpwjeMG3slbD3" : {
    "bananas" : 1100,
    "lastDayPlayed" : "2018-08-04",
    "longestStreak" : 1,
    "name" : "Bernard Andy Eugenio Gulla",
    "stars" : 9,
    "subscribed" : false,
    "uid" : "ymXlQBolGjc664PfpwjeMG3slbD3"
  },
  "ymddj0GvbKSeNTC3zDa6eYqjZnY2" : {
    "bananas" : 750,
    "lastDayPlayed" : "2018-12-10",
    "longestStreak" : 2,
    "name" : "Mark Wong",
    "stars" : 7,
    "subscribed" : false,
    "uid" : "ymddj0GvbKSeNTC3zDa6eYqjZnY2"
  },
  "ymi5YolrBOTmzPJs1ZEvAxWVzx92" : {
    "bananas" : 200,
    "lastDayPlayed" : "2018-06-17",
    "longestStreak" : 1,
    "name" : "amirul hariz",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "ymi5YolrBOTmzPJs1ZEvAxWVzx92"
  },
  "ymonOSLRONZxm99JFaPcbUoZSOF3" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Nur Gümüş",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "ymonOSLRONZxm99JFaPcbUoZSOF3"
  },
  "yn0kIHr19ub7hgxfrxIHab0MRS73" : {
    "bananas" : 2150,
    "lastDayPlayed" : "2019-01-24",
    "longestStreak" : 1,
    "name" : "",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "yn0kIHr19ub7hgxfrxIHab0MRS73"
  },
  "yn8Jn7LPoCcL3e6KZtGx3RmzDB63" : {
    "bananas" : 900,
    "lastDayPlayed" : "2018-05-09",
    "longestStreak" : 2,
    "name" : "Victoria Vang",
    "stars" : 8,
    "subscribed" : false,
    "uid" : "yn8Jn7LPoCcL3e6KZtGx3RmzDB63"
  },
  "ynGq0tckUyTBHFiB0c6v2Y2NxGH3" : {
    "bananas" : 2150,
    "lastDayPlayed" : "2018-10-11",
    "longestStreak" : 2,
    "name" : "Iolanda Rodrigues",
    "stars" : 15,
    "subscribed" : false,
    "uid" : "ynGq0tckUyTBHFiB0c6v2Y2NxGH3"
  },
  "ynXlyqthAfTrFbK8M4iQFFZTkYp2" : {
    "bananas" : 550,
    "lastDayPlayed" : "2018-12-05",
    "longestStreak" : 1,
    "name" : "diana smith",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "ynXlyqthAfTrFbK8M4iQFFZTkYp2"
  },
  "yniH9BMgoUYDFV3oNzBoKLq9BYj1" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Qiao Yee",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "yniH9BMgoUYDFV3oNzBoKLq9BYj1"
  },
  "yniTP0KsvfRDuw8weRArLiUDLR13" : {
    "bananas" : 200,
    "lastDayPlayed" : "2018-08-13",
    "longestStreak" : 1,
    "name" : "Daniel Horn",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "yniTP0KsvfRDuw8weRArLiUDLR13"
  },
  "ynp3NHnzBBYGf0WWiOdMDug0bXZ2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "ynp3NHnzBBYGf0WWiOdMDug0bXZ2"
  },
  "yo4XFheX0DRGXLWsDMwUwvPUvN23" : {
    "bananas" : 2100,
    "lastDayPlayed" : "2018-05-12",
    "longestStreak" : 2,
    "name" : "laila",
    "stars" : 14,
    "subscribed" : false,
    "uid" : "yo4XFheX0DRGXLWsDMwUwvPUvN23"
  },
  "yo5Sj0tkgFeTAmfU72ankN9rMwO2" : {
    "bananas" : 150,
    "lastDayPlayed" : "2019-02-06",
    "longestStreak" : 1,
    "name" : "Emma-Lee Crothers",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "yo5Sj0tkgFeTAmfU72ankN9rMwO2"
  },
  "yoDHUejMeshN1bOw9Bq671vMaph2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Ocelotl Kanpol",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "yoDHUejMeshN1bOw9Bq671vMaph2"
  },
  "yoGaR3ZFBhbzquGaxpj0kYSWZ3E3" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "박성재",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "yoGaR3ZFBhbzquGaxpj0kYSWZ3E3"
  },
  "yoSIZR2qFWPHCxezohG6A6j1Z0A3" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Victoria Lea",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "yoSIZR2qFWPHCxezohG6A6j1Z0A3"
  },
  "yoSPvRbIpNcrIC7UyvRvWjvaA4R2" : {
    "bananas" : 1700,
    "lastDayPlayed" : "2018-12-06",
    "longestStreak" : 1,
    "name" : "",
    "stars" : 12,
    "subscribed" : false,
    "uid" : "yoSPvRbIpNcrIC7UyvRvWjvaA4R2"
  },
  "yoSiLIddb4Qf37ojOkXBA9b6tsh1" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "小智",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "yoSiLIddb4Qf37ojOkXBA9b6tsh1"
  },
  "yoXSUlTGm0hSj484dC64eN7QtWK2" : {
    "bananas" : 200,
    "lastDayPlayed" : "2018-04-23",
    "longestStreak" : 1,
    "name" : "Brock Brethour",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "yoXSUlTGm0hSj484dC64eN7QtWK2"
  },
  "yobWfrtjiYawVW8raWI8zq8ek9q2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Tan Pham",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "yobWfrtjiYawVW8raWI8zq8ek9q2"
  },
  "yoeI8raUVZOK32ecbsoICmX9Q2O2" : {
    "bananas" : 800,
    "lastDayPlayed" : "2019-01-23",
    "longestStreak" : 1,
    "name" : "Nathanza",
    "stars" : 9,
    "subscribed" : false,
    "uid" : "yoeI8raUVZOK32ecbsoICmX9Q2O2"
  },
  "yonlA2cp08Zx0DPZlxHrtxJT2I02" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Louis Lucky Isman",
    "stars" : 4,
    "subscribed" : false,
    "uid" : "yonlA2cp08Zx0DPZlxHrtxJT2I02"
  },
  "yp88Mrrwr5dajzEqeG08O6GY7om1" : {
    "bananas" : 200,
    "lastDayPlayed" : "2018-07-16",
    "longestStreak" : 1,
    "name" : "Ming Jie Yang",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "yp88Mrrwr5dajzEqeG08O6GY7om1"
  },
  "ypGsurcbdlZGI0bIncgWCWKRVa13" : {
    "bananas" : 150,
    "lastDayPlayed" : "2018-08-30",
    "longestStreak" : 1,
    "name" : "Princess Pudding",
    "stars" : 4,
    "subscribed" : false,
    "uid" : "ypGsurcbdlZGI0bIncgWCWKRVa13"
  },
  "ypgEDWRRv6Y35QCgrL9M3orKdKv2" : {
    "bananas" : 200,
    "lastDayPlayed" : "2019-01-05",
    "longestStreak" : 2,
    "name" : "Joshua Du Chene",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "ypgEDWRRv6Y35QCgrL9M3orKdKv2"
  },
  "yq6ktPMebigBV1yx7npyjnXDJIr2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "younge55",
    "stars" : 3,
    "subscribed" : false,
    "uid" : "yq6ktPMebigBV1yx7npyjnXDJIr2"
  },
  "yq94enBRYydV8n6W9qHxV0F63HD3" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Zac Tan",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "yq94enBRYydV8n6W9qHxV0F63HD3"
  },
  "yr375I1LQbfwtVmsO1GNVZgjOvq1" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Martin Matthaei",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "yr375I1LQbfwtVmsO1GNVZgjOvq1"
  },
  "yrCPeLQLj5fZE4gqvO73z96puy82" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Paul Neill",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "yrCPeLQLj5fZE4gqvO73z96puy82"
  },
  "yrRdJiWXAASYiUDsGCEfvbiEqbh2" : {
    "bananas" : 5250,
    "lastDayPlayed" : "2018-08-23",
    "longestStreak" : 4,
    "name" : "Gregory S. Pettys",
    "stars" : 20,
    "subscribed" : true,
    "uid" : "yrRdJiWXAASYiUDsGCEfvbiEqbh2"
  },
  "yrSPbY41KmTmYft50H71utHRNYM2" : {
    "bananas" : 800,
    "lastDayPlayed" : "2018-11-18",
    "longestStreak" : 3,
    "name" : "Eddie Jones",
    "stars" : 9,
    "subscribed" : true,
    "uid" : "yrSPbY41KmTmYft50H71utHRNYM2"
  },
  "yrZF1LB7icQ2Bfe2ITGJRAy6gS23" : {
    "bananas" : 2000,
    "lastDayPlayed" : "2018-10-06",
    "longestStreak" : 2,
    "name" : "Wei Kiat Heng",
    "stars" : 15,
    "subscribed" : false,
    "uid" : "yrZF1LB7icQ2Bfe2ITGJRAy6gS23"
  },
  "yrgbxCOhkFedDQDEIccK0B6P8Bq2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "tang wai zhuan",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "yrgbxCOhkFedDQDEIccK0B6P8Bq2"
  },
  "yrjT0YXNQqPHfxuoQRfVcaDoBUo2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Daniel B.",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "yrjT0YXNQqPHfxuoQRfVcaDoBUo2"
  },
  "yrq6MqHlQQfxCF87VUEY7M7FfIJ3" : {
    "bananas" : 300,
    "lastDayPlayed" : "2018-12-06",
    "longestStreak" : 1,
    "name" : "Kiersten Haas",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "yrq6MqHlQQfxCF87VUEY7M7FfIJ3"
  },
  "ys9glgNgtlMUf2aiB8LCaSZ0NIW2" : {
    "bananas" : 800,
    "lastDayPlayed" : "2018-04-02",
    "longestStreak" : 1,
    "name" : "李小雅",
    "stars" : 9,
    "subscribed" : false,
    "uid" : "ys9glgNgtlMUf2aiB8LCaSZ0NIW2"
  },
  "ysd7rIlSYSU8N6gSHkUZuoZXmC23" : {
    "bananas" : 550,
    "lastDayPlayed" : "2018-11-30",
    "longestStreak" : 1,
    "name" : "Daniel Fullmann",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "ysd7rIlSYSU8N6gSHkUZuoZXmC23"
  },
  "ysp4Z26GGhYnuL5XBrd2G2mcdlr1" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Darren Tsie",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "ysp4Z26GGhYnuL5XBrd2G2mcdlr1"
  },
  "yt3igRsSroWWVNHCcvn7ZWQaU0d2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Tan Soo Ping (Metsp)",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "yt3igRsSroWWVNHCcvn7ZWQaU0d2"
  },
  "yt48ltv037VGBiDYZSyV0KWxJPy1" : {
    "bananas" : 100,
    "lastDayPlayed" : "2018-09-08",
    "longestStreak" : 1,
    "name" : "byron t",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "yt48ltv037VGBiDYZSyV0KWxJPy1"
  },
  "ytAi1L2gKSQA92eTcFNR24XraKR2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Caleb Bartel-Cruz",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "ytAi1L2gKSQA92eTcFNR24XraKR2"
  },
  "ytCyUP9ZcpZcZAQB35gQIdAJJby1" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Chetsa D. Ace",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "ytCyUP9ZcpZcZAQB35gQIdAJJby1"
  },
  "ytMYFxsVrIgYYOuLyazJVzJJB8F2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Seksan Duangsingtham",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "ytMYFxsVrIgYYOuLyazJVzJJB8F2"
  },
  "ytTn69sLo2Y7OuVgEgxMJ7e82hF2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "조썅",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "ytTn69sLo2Y7OuVgEgxMJ7e82hF2"
  },
  "ytVeJ5GWHaS8LPD0qd6zQOmPS7T2" : {
    "bananas" : 150,
    "lastDayPlayed" : "2018-05-13",
    "longestStreak" : 1,
    "name" : "水金",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "ytVeJ5GWHaS8LPD0qd6zQOmPS7T2"
  },
  "ytXuFVCwsLMoimdn6Xz2Bx5W1072" : {
    "bananas" : 1400,
    "lastDayPlayed" : "2018-05-08",
    "longestStreak" : 1,
    "name" : "Vasu Geramona",
    "stars" : 12,
    "subscribed" : false,
    "uid" : "ytXuFVCwsLMoimdn6Xz2Bx5W1072"
  },
  "ytyzFHdUQoaaWcH7rTUlTQAzV702" : {
    "bananas" : 2150,
    "lastDayPlayed" : "2019-01-05",
    "longestStreak" : 2,
    "name" : "",
    "stars" : 15,
    "subscribed" : false,
    "uid" : "ytyzFHdUQoaaWcH7rTUlTQAzV702"
  },
  "yuIdXqyJZzSIgSx8AADfcpKZYvz1" : {
    "bananas" : 1200,
    "lastDayPlayed" : "2019-01-20",
    "longestStreak" : 1,
    "name" : "Ginanjar Satya",
    "stars" : 11,
    "subscribed" : false,
    "uid" : "yuIdXqyJZzSIgSx8AADfcpKZYvz1"
  },
  "yuQqaZG7saYu9ZFCBFcnvvIDUnG3" : {
    "bananas" : 750,
    "lastDayPlayed" : "2018-11-01",
    "longestStreak" : 2,
    "name" : "aisyah park",
    "stars" : 7,
    "subscribed" : false,
    "uid" : "yuQqaZG7saYu9ZFCBFcnvvIDUnG3"
  },
  "yuc1YnVeKnWf5h72ihDynqop4tk1" : {
    "bananas" : 2650,
    "lastDayPlayed" : "2019-01-19",
    "longestStreak" : 1,
    "name" : "Ole",
    "stars" : 13,
    "subscribed" : false,
    "uid" : "yuc1YnVeKnWf5h72ihDynqop4tk1"
  },
  "yusdv5L6tVfjozEh2j74EQaCJ8u2" : {
    "bananas" : 3750,
    "lastDayPlayed" : "2019-02-10",
    "longestStreak" : 2,
    "name" : "Antonio Hugo",
    "stars" : 23,
    "subscribed" : true,
    "uid" : "yusdv5L6tVfjozEh2j74EQaCJ8u2"
  },
  "yv0aHXAP5ISkmvffxI5MMwOY7q83" : {
    "bananas" : 800,
    "lastDayPlayed" : "2018-09-18",
    "longestStreak" : 1,
    "name" : "Yanti Praptika",
    "stars" : 9,
    "subscribed" : false,
    "uid" : "yv0aHXAP5ISkmvffxI5MMwOY7q83"
  },
  "yv9jageV71WPnFZKip4pbHyGUT42" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Юрий Юр",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "yv9jageV71WPnFZKip4pbHyGUT42"
  },
  "yvHQWi0rYqfSnqX3nO2I84O3jkp1" : {
    "bananas" : 200,
    "lastDayPlayed" : "2018-11-23",
    "longestStreak" : 1,
    "name" : "Shir Friedman",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "yvHQWi0rYqfSnqX3nO2I84O3jkp1"
  },
  "yvx5LeetLrbbmKwXcPrL603owlg2" : {
    "bananas" : 600,
    "lastDayPlayed" : "2018-12-15",
    "longestStreak" : 1,
    "name" : "Nick dfergfr",
    "stars" : 7,
    "subscribed" : false,
    "uid" : "yvx5LeetLrbbmKwXcPrL603owlg2"
  },
  "yw3SBcYFJcbqO5sygucsK3tD1P62" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Andrew Huli",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "yw3SBcYFJcbqO5sygucsK3tD1P62"
  },
  "ywDuLHGhIqfx5D0ZHidMftfrrpg2" : {
    "bananas" : 3600,
    "lastDayPlayed" : "2018-05-24",
    "longestStreak" : 3,
    "name" : "Mark Appleton",
    "stars" : 14,
    "subscribed" : false,
    "uid" : "ywDuLHGhIqfx5D0ZHidMftfrrpg2"
  },
  "ywHYJA68VZcp0rrziU5GYAkTDPE2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Lizzy Lezhava",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "ywHYJA68VZcp0rrziU5GYAkTDPE2"
  },
  "ywR5fUyYMVTpmOEyzdHWbEiNZ1x2" : {
    "bananas" : 400,
    "lastDayPlayed" : "2019-02-06",
    "longestStreak" : 1,
    "name" : "Nhật Linh",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "ywR5fUyYMVTpmOEyzdHWbEiNZ1x2"
  },
  "yws2KY8xBkMJDVRpfmInzzjWlRI2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "黄嘉仪",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "yws2KY8xBkMJDVRpfmInzzjWlRI2"
  },
  "yxtWwo0CtXXsRooLiRy2S0U1ND63" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Alvin Lee",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "yxtWwo0CtXXsRooLiRy2S0U1ND63"
  },
  "yy1gzdAO5YUJEW9DNdclPsrXvgR2" : {
    "bananas" : 300,
    "lastDayPlayed" : "2018-10-30",
    "longestStreak" : 1,
    "name" : "",
    "stars" : 4,
    "subscribed" : false,
    "uid" : "yy1gzdAO5YUJEW9DNdclPsrXvgR2"
  },
  "yy4BetXI96bnkoUq7Vp0YtMyxMx2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "",
    "stars" : 5,
    "subscribed" : true,
    "uid" : "yy4BetXI96bnkoUq7Vp0YtMyxMx2"
  },
  "yy4I38Qdg5W4clyDUfGXD5SqI2c2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Pedro Vizioli",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "yy4I38Qdg5W4clyDUfGXD5SqI2c2"
  },
  "yyJ2kFlwqNW5bRFfJfzt2r2LAmV2" : {
    "bananas" : 1550,
    "lastDayPlayed" : "2018-12-16",
    "longestStreak" : 1,
    "name" : "Nana Nani",
    "stars" : 7,
    "subscribed" : false,
    "uid" : "yyJ2kFlwqNW5bRFfJfzt2r2LAmV2"
  },
  "yyPvMrXzpKUYbmmcDwDc3PB8Iam2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "crisity liang",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "yyPvMrXzpKUYbmmcDwDc3PB8Iam2"
  },
  "yyQjSDcmpsNsK7MhXcJJrR2rFRQ2" : {
    "bananas" : 1100,
    "lastDayPlayed" : "2018-04-08",
    "longestStreak" : 1,
    "name" : "Nicki Barbie Minaj",
    "stars" : 8,
    "subscribed" : false,
    "uid" : "yyQjSDcmpsNsK7MhXcJJrR2rFRQ2"
  },
  "yyW2jYRrNHWtRybIbM0pnM0KnpW2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "ป่า ปลาหมึก",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "yyW2jYRrNHWtRybIbM0pnM0KnpW2"
  },
  "yya5y47cvsWDD1eeB7q7xneJPj33" : {
    "bananas" : 1100,
    "lastDayPlayed" : "2019-01-10",
    "longestStreak" : 1,
    "name" : "Ernest Siow",
    "stars" : 9,
    "subscribed" : false,
    "uid" : "yya5y47cvsWDD1eeB7q7xneJPj33"
  },
  "yyxUQwWgOueaq66AN675WPZv4bD3" : {
    "bananas" : 100,
    "lastDayPlayed" : "2018-03-29",
    "longestStreak" : 1,
    "name" : "tom",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "yyxUQwWgOueaq66AN675WPZv4bD3"
  },
  "yz9Hh2H1LXfpMNQ5UupLYFSYnR22" : {
    "bananas" : 200,
    "lastDayPlayed" : "2018-06-06",
    "longestStreak" : 1,
    "name" : "binshi xiao",
    "stars" : 4,
    "subscribed" : false,
    "uid" : "yz9Hh2H1LXfpMNQ5UupLYFSYnR22"
  },
  "yzGnMva1SJTBRiteWWGPVPfvybo2" : {
    "bananas" : 150,
    "lastDayPlayed" : "2018-08-22",
    "longestStreak" : 1,
    "name" : "Mark English",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "yzGnMva1SJTBRiteWWGPVPfvybo2"
  },
  "yzVAdQBq9fQ45AaF0kmuToNUSKC2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Tommy Manichanh",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "yzVAdQBq9fQ45AaF0kmuToNUSKC2"
  },
  "yzbsWc1DrmfQl3lOOne1cOXvXOU2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "张楠",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "yzbsWc1DrmfQl3lOOne1cOXvXOU2"
  },
  "yzgOjzYSRFUnJmLI9ZkyGvyltrn2" : {
    "bananas" : 200,
    "lastDayPlayed" : "2018-12-14",
    "longestStreak" : 1,
    "name" : "Aleksej Brume",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "yzgOjzYSRFUnJmLI9ZkyGvyltrn2"
  },
  "yzj1uxXIzrTJk8aUTEtiOCY4og93" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Atiey Denizz",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "yzj1uxXIzrTJk8aUTEtiOCY4og93"
  },
  "yzoLr5Cj9NVZYVGaPHb8dKnah9e2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Minami Soma",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "yzoLr5Cj9NVZYVGaPHb8dKnah9e2"
  },
  "yzqGJMNMEPU7lsjq7TE19qmectr1" : {
    "bananas" : 4100,
    "lastDayPlayed" : "2018-11-27",
    "longestStreak" : 3,
    "name" : "Beatrice Kalalo",
    "stars" : 14,
    "subscribed" : false,
    "uid" : "yzqGJMNMEPU7lsjq7TE19qmectr1"
  },
  "z00HnRNFIdgQaX1mjUy6alaa8tN2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Xavier Mercedes Thiefofhearts",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "z00HnRNFIdgQaX1mjUy6alaa8tN2"
  },
  "z0SL3HFXFoNCNxBMfVlfw4CcRx83" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Pei Chi",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "z0SL3HFXFoNCNxBMfVlfw4CcRx83"
  },
  "z0V6TdKY9XhIrfA4sJSLtRiwJ8p1" : {
    "bananas" : 1750,
    "lastDayPlayed" : "2018-08-18",
    "longestStreak" : 1,
    "name" : "Danuja Boteju",
    "stars" : 11,
    "subscribed" : false,
    "uid" : "z0V6TdKY9XhIrfA4sJSLtRiwJ8p1"
  },
  "z0hZrUBLKufKeFWO2otxZRBm9U32" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "John Simonsen",
    "stars" : 0,
    "subscribed" : false,
    "uid" : "z0hZrUBLKufKeFWO2otxZRBm9U32"
  },
  "z0lrfc2WkHcCG1UTvwRV76LykzE3" : {
    "bananas" : 200,
    "lastDayPlayed" : "2018-11-14",
    "longestStreak" : 1,
    "name" : "Li Lulu",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "z0lrfc2WkHcCG1UTvwRV76LykzE3"
  },
  "z11GPjsorkX7QcWrKCuUdoKjDz03" : {
    "bananas" : 750,
    "lastDayPlayed" : "2019-01-08",
    "longestStreak" : 1,
    "name" : "kyuho kim",
    "stars" : 7,
    "subscribed" : false,
    "uid" : "z11GPjsorkX7QcWrKCuUdoKjDz03"
  },
  "z12664btwsMUWMvf2krKYMgGZos1" : {
    "bananas" : 200,
    "lastDayPlayed" : "2018-10-07",
    "longestStreak" : 1,
    "name" : "Avita Sirimitr",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "z12664btwsMUWMvf2krKYMgGZos1"
  },
  "z14XAQIat8bTKwm37XXAtYdRy8p1" : {
    "bananas" : 300,
    "lastDayPlayed" : "2018-09-08",
    "longestStreak" : 1,
    "name" : "Ed Ruiz",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "z14XAQIat8bTKwm37XXAtYdRy8p1"
  },
  "z154noE5w9YScrE75dm0dOitueg2" : {
    "bananas" : 800,
    "lastDayPlayed" : "2018-04-13",
    "longestStreak" : 1,
    "name" : "Hiu Tung Shek",
    "stars" : 9,
    "subscribed" : false,
    "uid" : "z154noE5w9YScrE75dm0dOitueg2"
  },
  "z159rqfnAhUsyFIoRlptymEWheP2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Alvin Lai",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "z159rqfnAhUsyFIoRlptymEWheP2"
  },
  "z16TRDZM64M0BfRPeSFMtdTYr042" : {
    "bananas" : 1450,
    "lastDayPlayed" : "2018-11-15",
    "longestStreak" : 1,
    "name" : "Zoe Bonafe",
    "stars" : 10,
    "subscribed" : false,
    "uid" : "z16TRDZM64M0BfRPeSFMtdTYr042"
  },
  "z16ejSkA40TmfyiJbbJGwgyR01x1" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "อุทัย แทนคอน",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "z16ejSkA40TmfyiJbbJGwgyR01x1"
  },
  "z1DlsaXyEwMPv53mPjBAujQKV9t1" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Nicholas Heng II",
    "stars" : 4,
    "subscribed" : false,
    "uid" : "z1DlsaXyEwMPv53mPjBAujQKV9t1"
  },
  "z1GnXgTtbWOgNQPfeMJAmsj6HMa2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "qianyan li",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "z1GnXgTtbWOgNQPfeMJAmsj6HMa2"
  },
  "z1LCU6jviFPeS37RIdp1EGDNs8N2" : {
    "bananas" : 600,
    "lastDayPlayed" : "2018-06-12",
    "longestStreak" : 1,
    "name" : "Andreas Engoy",
    "stars" : 8,
    "subscribed" : false,
    "uid" : "z1LCU6jviFPeS37RIdp1EGDNs8N2"
  },
  "z1QlzHOuskgQjh9X3DXsyn0cMVT2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Mindy Mcdaniel",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "z1QlzHOuskgQjh9X3DXsyn0cMVT2"
  },
  "z1b291SyyPewxqxcykF5fHc15uI2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Lewie Isidro",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "z1b291SyyPewxqxcykF5fHc15uI2"
  },
  "z1d2ESYe9BcMTpXe8VxsmtpquNp1" : {
    "bananas" : 200,
    "lastDayPlayed" : "2018-06-25",
    "longestStreak" : 1,
    "name" : "Nicole Tsai",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "z1d2ESYe9BcMTpXe8VxsmtpquNp1"
  },
  "z1j35bKOVJRpdpczzEccAwZXC3b2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Geet Sabharwal",
    "stars" : 0,
    "subscribed" : false,
    "uid" : "z1j35bKOVJRpdpczzEccAwZXC3b2"
  },
  "z1kvBOXHCpaadn4Yrw7UQEy4PJ13" : {
    "bananas" : 800,
    "lastDayPlayed" : "2018-12-23",
    "longestStreak" : 1,
    "name" : "Aytac Kücükoglu",
    "stars" : 9,
    "subscribed" : false,
    "uid" : "z1kvBOXHCpaadn4Yrw7UQEy4PJ13"
  },
  "z1sPPlQaaqSXmP1OR7Bf0mIxiko2" : {
    "bananas" : 200,
    "lastDayPlayed" : "2018-08-10",
    "longestStreak" : 1,
    "name" : "",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "z1sPPlQaaqSXmP1OR7Bf0mIxiko2"
  },
  "z1vrWHwukmWQV7kp5SlkR8ne7Tu2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Zainab Isha",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "z1vrWHwukmWQV7kp5SlkR8ne7Tu2"
  },
  "z1wyXCIVK6bfRnZVOr0taSvrvB53" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Abby Strange",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "z1wyXCIVK6bfRnZVOr0taSvrvB53"
  },
  "z293hH8osXbPNZIFnDOagyfJaJy2" : {
    "bananas" : 200,
    "lastDayPlayed" : "2018-09-11",
    "longestStreak" : 1,
    "name" : "Off Beat",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "z293hH8osXbPNZIFnDOagyfJaJy2"
  },
  "z2ATS93yfZgvmieW40ltcdVjk0D3" : {
    "bananas" : 200,
    "lastDayPlayed" : "2018-06-22",
    "longestStreak" : 1,
    "name" : "Yến Nhi",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "z2ATS93yfZgvmieW40ltcdVjk0D3"
  },
  "z2FFX2uW5QTduocHmyzva9170y22" : {
    "bananas" : 1750,
    "lastDayPlayed" : "2018-07-05",
    "longestStreak" : 2,
    "name" : "Damdim Doum",
    "stars" : 10,
    "subscribed" : false,
    "uid" : "z2FFX2uW5QTduocHmyzva9170y22"
  },
  "z2NwaBp1fMfOzmiRaPfByOLgste2" : {
    "bananas" : 700,
    "lastDayPlayed" : "2018-05-23",
    "longestStreak" : 1,
    "name" : "Andreas Steurer",
    "stars" : 7,
    "subscribed" : false,
    "uid" : "z2NwaBp1fMfOzmiRaPfByOLgste2"
  },
  "z2YsmwEl9abzIGXpeq3w7ProJGL2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Olivier Gaudin",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "z2YsmwEl9abzIGXpeq3w7ProJGL2"
  },
  "z30C0LE2yZZ5agApZuRg6QGRkSD3" : {
    "bananas" : 200,
    "lastDayPlayed" : "2019-02-01",
    "longestStreak" : 1,
    "name" : "Sofia Elbaamrani",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "z30C0LE2yZZ5agApZuRg6QGRkSD3"
  },
  "z39j1OgxZYcsxVlU226STEuaKKt2" : {
    "bananas" : 400,
    "lastDayPlayed" : "2018-08-11",
    "longestStreak" : 1,
    "name" : "Thomas Nelson",
    "stars" : 4,
    "subscribed" : false,
    "uid" : "z39j1OgxZYcsxVlU226STEuaKKt2"
  },
  "z3Hfnvu0EiZxVoL7JIibClu43ry1" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Lawrence Ong",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "z3Hfnvu0EiZxVoL7JIibClu43ry1"
  },
  "z3aQznUPmiUSFGSrs3ZgXYlesTv2" : {
    "bananas" : 1800,
    "lastDayPlayed" : "2018-11-23",
    "longestStreak" : 1,
    "name" : "",
    "stars" : 10,
    "subscribed" : false,
    "uid" : "z3aQznUPmiUSFGSrs3ZgXYlesTv2"
  },
  "z3cGuT4BkXT6oR2ETed873Rbmg63" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Rhea",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "z3cGuT4BkXT6oR2ETed873Rbmg63"
  },
  "z3fugLrchDYHgi2mEXmFexOSMI43" : {
    "bananas" : 150,
    "lastDayPlayed" : "2019-01-01",
    "longestStreak" : 1,
    "name" : "Ghehan Tuiza Gonzaga",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "z3fugLrchDYHgi2mEXmFexOSMI43"
  },
  "z3gFk4xg72O2aCAfZK5HqPAZtwI2" : {
    "bananas" : 800,
    "lastDayPlayed" : "2019-01-20",
    "longestStreak" : 1,
    "name" : "Elsa Chuan",
    "stars" : 9,
    "subscribed" : false,
    "uid" : "z3gFk4xg72O2aCAfZK5HqPAZtwI2"
  },
  "z3pLrySIr8TaTLCNxtmTzJ5sbZc2" : {
    "bananas" : 500,
    "lastDayPlayed" : "2018-07-09",
    "longestStreak" : 2,
    "name" : "王尚昌",
    "stars" : 3,
    "subscribed" : false,
    "uid" : "z3pLrySIr8TaTLCNxtmTzJ5sbZc2"
  },
  "z3v9IyDw2IQ0US8QnBe7XgKYFBE2" : {
    "bananas" : 700,
    "lastDayPlayed" : "2019-01-11",
    "longestStreak" : 2,
    "name" : "Dante Danuco",
    "stars" : 7,
    "subscribed" : false,
    "uid" : "z3v9IyDw2IQ0US8QnBe7XgKYFBE2"
  },
  "z48Wfqhx5xaUBkLyMFCElVuiDFr1" : {
    "bananas" : 2500,
    "lastDayPlayed" : "2018-05-25",
    "longestStreak" : 3,
    "name" : "Atlan Gonozal",
    "stars" : 15,
    "subscribed" : false,
    "uid" : "z48Wfqhx5xaUBkLyMFCElVuiDFr1"
  },
  "z4BrQeSC2JdYBy7y3ogViSZnwA63" : {
    "bananas" : 400,
    "lastDayPlayed" : "2018-05-21",
    "longestStreak" : 1,
    "name" : "Sebastian Gößl",
    "stars" : 7,
    "subscribed" : false,
    "uid" : "z4BrQeSC2JdYBy7y3ogViSZnwA63"
  },
  "z4J1tfLxqxVLRoz7g5KdWPHgMX62" : {
    "bananas" : 250,
    "lastDayPlayed" : "2019-01-07",
    "longestStreak" : 2,
    "name" : "Megane Zangger",
    "stars" : 4,
    "subscribed" : false,
    "uid" : "z4J1tfLxqxVLRoz7g5KdWPHgMX62"
  },
  "z4apUshNhCb5FkLpmRKzjk3sePs1" : {
    "bananas" : 750,
    "lastDayPlayed" : "2018-08-22",
    "longestStreak" : 1,
    "name" : "Angella Belladhita Karoline",
    "stars" : 7,
    "subscribed" : false,
    "uid" : "z4apUshNhCb5FkLpmRKzjk3sePs1"
  },
  "z4lPYaqr4LSxsqvW7xGH70yBtO22" : {
    "bananas" : 2000,
    "lastDayPlayed" : "2019-01-13",
    "longestStreak" : 3,
    "name" : "Thao Nguyen",
    "stars" : 15,
    "subscribed" : false,
    "uid" : "z4lPYaqr4LSxsqvW7xGH70yBtO22"
  },
  "z4rQXao1uwYh2ur4dfzDHGwOp5A2" : {
    "bananas" : 3150,
    "lastDayPlayed" : "2018-12-27",
    "longestStreak" : 1,
    "name" : "David Seok",
    "stars" : 20,
    "subscribed" : false,
    "uid" : "z4rQXao1uwYh2ur4dfzDHGwOp5A2"
  },
  "z59xxcF2Y2YBzFbRbaZg1AqU1vj1" : {
    "bananas" : 200,
    "lastDayPlayed" : "2018-07-01",
    "longestStreak" : 1,
    "name" : "",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "z59xxcF2Y2YBzFbRbaZg1AqU1vj1"
  },
  "z5AUSxZL80exW3wlsLA1swg0vVQ2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "高紹啟",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "z5AUSxZL80exW3wlsLA1swg0vVQ2"
  },
  "z5I2l0nLnqas8H4bQEAiIX6iTT72" : {
    "bananas" : 5600,
    "lastDayPlayed" : "2018-08-10",
    "longestStreak" : 4,
    "name" : "T-ran TheMan",
    "stars" : 27,
    "subscribed" : false,
    "uid" : "z5I2l0nLnqas8H4bQEAiIX6iTT72"
  },
  "z5f976TTaBfzfVl9b3h1ZT5dxWq1" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Maria florencia Simone",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "z5f976TTaBfzfVl9b3h1ZT5dxWq1"
  },
  "z5pnPic3KQQ0HBg8c85ejlQmZpS2" : {
    "bananas" : 500,
    "lastDayPlayed" : "2019-01-05",
    "longestStreak" : 1,
    "name" : "",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "z5pnPic3KQQ0HBg8c85ejlQmZpS2"
  },
  "z60rROZVm6ZVrIgRObZVAbfcqQ33" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Madeleine Franj",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "z60rROZVm6ZVrIgRObZVAbfcqQ33"
  },
  "z649K1u1MTNOmZ8aWVo1u8Sung72" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Nick Watene",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "z649K1u1MTNOmZ8aWVo1u8Sung72"
  },
  "z6RVBacBiMbmS5xtTZXcDcyeQZI3" : {
    "bananas" : 3400,
    "lastDayPlayed" : "2018-08-09",
    "longestStreak" : 2,
    "name" : "Khwanoi",
    "stars" : 8,
    "subscribed" : false,
    "uid" : "z6RVBacBiMbmS5xtTZXcDcyeQZI3"
  },
  "z6xfABXNKEUqNGXkM4PTnS9LCC92" : {
    "bananas" : 1800,
    "lastDayPlayed" : "2019-01-01",
    "longestStreak" : 2,
    "name" : "Grace Chonmany",
    "stars" : 8,
    "subscribed" : false,
    "uid" : "z6xfABXNKEUqNGXkM4PTnS9LCC92"
  },
  "z729ZQFVSXN1eAJeSaPDUkvS8UY2" : {
    "bananas" : 750,
    "lastDayPlayed" : "2018-09-03",
    "longestStreak" : 1,
    "name" : "Venkata Surekha",
    "stars" : 8,
    "subscribed" : false,
    "uid" : "z729ZQFVSXN1eAJeSaPDUkvS8UY2"
  },
  "z7IbNBFh5FZ7wiIMHETRpfimMzj1" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Rania badar",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "z7IbNBFh5FZ7wiIMHETRpfimMzj1"
  },
  "z7LaOBiAypPaPfPVhgE6vgfgp2r1" : {
    "bananas" : 400,
    "lastDayPlayed" : "2018-11-29",
    "longestStreak" : 1,
    "name" : "Kyle Nelson",
    "stars" : 7,
    "subscribed" : false,
    "uid" : "z7LaOBiAypPaPfPVhgE6vgfgp2r1"
  },
  "z7SD5HJRZCYnCYNpk3gseTaLbF82" : {
    "bananas" : 150,
    "lastDayPlayed" : "2018-08-18",
    "longestStreak" : 1,
    "name" : "",
    "stars" : 5,
    "subscribed" : true,
    "uid" : "z7SD5HJRZCYnCYNpk3gseTaLbF82"
  },
  "z7UqpNDYugVpzkzi9LKT8ns4T8w2" : {
    "bananas" : 800,
    "lastDayPlayed" : "2019-01-31",
    "longestStreak" : 2,
    "name" : "",
    "stars" : 4,
    "subscribed" : false,
    "uid" : "z7UqpNDYugVpzkzi9LKT8ns4T8w2"
  },
  "z7ZQBUiGFvRQgbO7BfyYnP4u2cZ2" : {
    "bananas" : 1000,
    "lastDayPlayed" : "2018-09-18",
    "longestStreak" : 1,
    "name" : "Muhd Sabir Ibrahim",
    "stars" : 10,
    "subscribed" : false,
    "uid" : "z7ZQBUiGFvRQgbO7BfyYnP4u2cZ2"
  },
  "z7fRH98VgaM0Dz5O5h1VrTo4qc22" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "احمد اسماعيل",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "z7fRH98VgaM0Dz5O5h1VrTo4qc22"
  },
  "z7ucAO8UMkTrJEl6oTVzfVwP6D53" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Shawn Griswold",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "z7ucAO8UMkTrJEl6oTVzfVwP6D53"
  },
  "z8B9Q49srNQOzo5vSadHnqW3geG2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "王羽萍",
    "stars" : 4,
    "subscribed" : false,
    "uid" : "z8B9Q49srNQOzo5vSadHnqW3geG2"
  },
  "z8EF5dsJxWhEEDvnjDhKX9JsXNd2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Warren Young",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "z8EF5dsJxWhEEDvnjDhKX9JsXNd2"
  },
  "z8RUiiuvb4S2kP7LQyMHjwH6jS62" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "z8RUiiuvb4S2kP7LQyMHjwH6jS62"
  },
  "z8ekzon64wYPQCz6EBpz4trv4jG2" : {
    "bananas" : 150,
    "lastDayPlayed" : "2018-05-07",
    "longestStreak" : 1,
    "name" : "Clayton Arn Broncheau",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "z8ekzon64wYPQCz6EBpz4trv4jG2"
  },
  "z8juUbIREqXxHAXORfWultk8QV23" : {
    "bananas" : 150,
    "lastDayPlayed" : "2018-10-24",
    "longestStreak" : 1,
    "name" : "Cheung Yung Ng",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "z8juUbIREqXxHAXORfWultk8QV23"
  },
  "z9P2rPiQ39Sj786CpJIC0BlUUeS2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Yu Eva",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "z9P2rPiQ39Sj786CpJIC0BlUUeS2"
  },
  "z9WiHWYhsiTAEEyH9ERfMj5z81m1" : {
    "bananas" : 3350,
    "lastDayPlayed" : "2019-01-20",
    "longestStreak" : 1,
    "name" : "",
    "stars" : 18,
    "subscribed" : false,
    "uid" : "z9WiHWYhsiTAEEyH9ERfMj5z81m1"
  },
  "z9pzIUcQ4kNGy78cuZnEZjEFGy22" : {
    "bananas" : 2650,
    "lastDayPlayed" : "2019-01-06",
    "longestStreak" : 1,
    "name" : "",
    "stars" : 16,
    "subscribed" : false,
    "uid" : "z9pzIUcQ4kNGy78cuZnEZjEFGy22"
  },
  "z9r8npWQOlY2oYbCcf8oHCXvDly1" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Jeffrey Borum",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "z9r8npWQOlY2oYbCcf8oHCXvDly1"
  },
  "zA1unJJE9TQh02oiILML6TrY3ZI2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Ivon yupiyei",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zA1unJJE9TQh02oiILML6TrY3ZI2"
  },
  "zA3OyMI0MEZAPXOpzOCdz1h3y6Y2" : {
    "bananas" : 200,
    "lastDayPlayed" : "2018-08-12",
    "longestStreak" : 1,
    "name" : "Low Chin Leong Loeng Chin Low",
    "stars" : 3,
    "subscribed" : false,
    "uid" : "zA3OyMI0MEZAPXOpzOCdz1h3y6Y2"
  },
  "zADk35N5Z2Wd2Nj573HoSC2MlMK2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Jimmy Tan",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zADk35N5Z2Wd2Nj573HoSC2MlMK2"
  },
  "zAE5V4Q7ISbpbIR5a5art10TlfP2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zAE5V4Q7ISbpbIR5a5art10TlfP2"
  },
  "zATT3rA1m4O6bBAjhdcAY8fdt6m2" : {
    "bananas" : 200,
    "lastDayPlayed" : "2019-01-05",
    "longestStreak" : 1,
    "name" : "Amber Chong",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "zATT3rA1m4O6bBAjhdcAY8fdt6m2"
  },
  "zAyvQgkMOUTZXMlkURMT3jlP1T83" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "落叶乔木",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zAyvQgkMOUTZXMlkURMT3jlP1T83"
  },
  "zB4tV9SDrDWwTy1y9h2Wv39Kf2Z2" : {
    "bananas" : 200,
    "lastDayPlayed" : "2018-09-10",
    "longestStreak" : 1,
    "name" : "Poison Flower",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "zB4tV9SDrDWwTy1y9h2Wv39Kf2Z2"
  },
  "zBItRZXmNCdh72KqkIo9PWsWKtR2" : {
    "bananas" : 100,
    "lastDayPlayed" : "2018-09-21",
    "longestStreak" : 1,
    "name" : "杨君芝",
    "stars" : 4,
    "subscribed" : false,
    "uid" : "zBItRZXmNCdh72KqkIo9PWsWKtR2"
  },
  "zBgGPzU0saQuZHL7EH3T8xX6zCm2" : {
    "bananas" : 18250,
    "lastDayPlayed" : "2019-02-01",
    "longestStreak" : 13,
    "name" : "Bryan Holleman",
    "stars" : 66,
    "subscribed" : true,
    "uid" : "zBgGPzU0saQuZHL7EH3T8xX6zCm2"
  },
  "zBqRAlo7QSRJT75fcnMC4cA3PkG3" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "venus chong",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zBqRAlo7QSRJT75fcnMC4cA3PkG3"
  },
  "zBqesUIHQxZhKlmeiuIeX1URPrk2" : {
    "bananas" : 3200,
    "lastDayPlayed" : "2018-07-01",
    "longestStreak" : 1,
    "name" : "OneEyed JackBurton",
    "stars" : 15,
    "subscribed" : false,
    "uid" : "zBqesUIHQxZhKlmeiuIeX1URPrk2"
  },
  "zC2eZI99BTWZabnyLiP7eDn4HPn2" : {
    "bananas" : 400,
    "lastDayPlayed" : "2018-12-18",
    "longestStreak" : 1,
    "name" : "Rᴇsᴘᴀᴛɪ Kᴀsɪʜ",
    "stars" : 7,
    "subscribed" : false,
    "uid" : "zC2eZI99BTWZabnyLiP7eDn4HPn2"
  },
  "zCdLX0GNWsU7fEwGrAppMxUiIZQ2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Bing Zhu",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zCdLX0GNWsU7fEwGrAppMxUiIZQ2"
  },
  "zCeacxK19nN2qe2LKMlpp8cw3FI2" : {
    "bananas" : 400,
    "lastDayPlayed" : "2018-04-07",
    "longestStreak" : 1,
    "name" : "mat clark",
    "stars" : 7,
    "subscribed" : false,
    "uid" : "zCeacxK19nN2qe2LKMlpp8cw3FI2"
  },
  "zCgeyCZynmZDuckVUfkxk3tNWDz2" : {
    "bananas" : 600,
    "lastDayPlayed" : "2018-11-26",
    "longestStreak" : 1,
    "name" : "Julien Anderson Nadeau",
    "stars" : 7,
    "subscribed" : false,
    "uid" : "zCgeyCZynmZDuckVUfkxk3tNWDz2"
  },
  "zCjuR4mh5waicF2sGAc5a5wBfzy1" : {
    "bananas" : 5850,
    "lastDayPlayed" : "2018-04-12",
    "longestStreak" : 2,
    "name" : "Julius tan",
    "stars" : 29,
    "subscribed" : false,
    "uid" : "zCjuR4mh5waicF2sGAc5a5wBfzy1"
  },
  "zClh4JgBpLO3mMUSjvgCSr2cNml1" : {
    "bananas" : 100,
    "lastDayPlayed" : "2018-07-29",
    "longestStreak" : 1,
    "name" : "Francis Cheung",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zClh4JgBpLO3mMUSjvgCSr2cNml1"
  },
  "zCpS1Z4orTfwRYr7HCfDCVIeVt73" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Leonard",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zCpS1Z4orTfwRYr7HCfDCVIeVt73"
  },
  "zD3amf9dRkb9493I4oWiAu178Qi2" : {
    "bananas" : 450,
    "lastDayPlayed" : "2019-01-03",
    "longestStreak" : 1,
    "name" : "Andy Hoyle",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "zD3amf9dRkb9493I4oWiAu178Qi2"
  },
  "zDEHlcQuNogrlRDSP0LPgqB2sOV2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Laurence Daniel",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zDEHlcQuNogrlRDSP0LPgqB2sOV2"
  },
  "zDEg7jfgQ5ch0C4J4DaJFRlRIlb2" : {
    "bananas" : 400,
    "lastDayPlayed" : "2018-04-17",
    "longestStreak" : 1,
    "name" : "Gan Zhi Xuan",
    "stars" : 7,
    "subscribed" : false,
    "uid" : "zDEg7jfgQ5ch0C4J4DaJFRlRIlb2"
  },
  "zDHhDho9h5fTDntQhyEg66RMvqK2" : {
    "bananas" : 6550,
    "lastDayPlayed" : "2018-09-18",
    "longestStreak" : 6,
    "name" : "Emma",
    "stars" : 24,
    "subscribed" : false,
    "uid" : "zDHhDho9h5fTDntQhyEg66RMvqK2"
  },
  "zDV2IhOoEgSYTqhB0oSgcN4YEij1" : {
    "bananas" : 1650,
    "lastDayPlayed" : "2018-05-23",
    "longestStreak" : 1,
    "name" : "Raphael Perroud",
    "stars" : 11,
    "subscribed" : false,
    "uid" : "zDV2IhOoEgSYTqhB0oSgcN4YEij1"
  },
  "zDXfzC9hw2Xe6JUmWcmqbiYt4eo1" : {
    "bananas" : 200,
    "lastDayPlayed" : "2018-12-11",
    "longestStreak" : 1,
    "name" : "_レナ",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "zDXfzC9hw2Xe6JUmWcmqbiYt4eo1"
  },
  "zDd6KlhaoKOEE22bbUfAQ7ahRIp2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Ivan Peral",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zDd6KlhaoKOEE22bbUfAQ7ahRIp2"
  },
  "zDeUeaafz4YGiGMyInlqR6aJhcE3" : {
    "bananas" : 4850,
    "lastDayPlayed" : "2018-11-23",
    "longestStreak" : 3,
    "name" : "",
    "stars" : 24,
    "subscribed" : false,
    "uid" : "zDeUeaafz4YGiGMyInlqR6aJhcE3"
  },
  "zE0W0LAE0KQCGcM9yFqA8bC8zRA3" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Rain Bucao Ramon",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zE0W0LAE0KQCGcM9yFqA8bC8zRA3"
  },
  "zENP7og5QLdb17sghjIRbCGminq1" : {
    "bananas" : 3000,
    "lastDayPlayed" : "2018-09-09",
    "longestStreak" : 3,
    "name" : "",
    "stars" : 20,
    "subscribed" : false,
    "uid" : "zENP7og5QLdb17sghjIRbCGminq1"
  },
  "zEaX8gIOmUN10j9u1JdzBF84ybb2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Cassie Tanielu",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zEaX8gIOmUN10j9u1JdzBF84ybb2"
  },
  "zEjso3ZuyRUMnYKQQO83n4lMCEF3" : {
    "bananas" : 1100,
    "lastDayPlayed" : "2018-11-18",
    "longestStreak" : 1,
    "name" : "",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "zEjso3ZuyRUMnYKQQO83n4lMCEF3"
  },
  "zF1mvWPB9KQk4NKGOtt90eAcfGd2" : {
    "bananas" : 200,
    "lastDayPlayed" : "2018-06-28",
    "longestStreak" : 1,
    "name" : "Takoda Carter",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "zF1mvWPB9KQk4NKGOtt90eAcfGd2"
  },
  "zFVZhSXA5JQeDhz4kSs13nAlDhG2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Stingyshima Kei",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zFVZhSXA5JQeDhz4kSs13nAlDhG2"
  },
  "zFWA3lfviJU1P0TCpa32CgGC12z1" : {
    "bananas" : 100,
    "lastDayPlayed" : "2018-04-19",
    "longestStreak" : 1,
    "name" : "Pang Shanahan",
    "stars" : 4,
    "subscribed" : false,
    "uid" : "zFWA3lfviJU1P0TCpa32CgGC12z1"
  },
  "zFaFCZHPSuPwkT4XhqfjYFmSakJ3" : {
    "bananas" : 200,
    "lastDayPlayed" : "2019-01-20",
    "longestStreak" : 1,
    "name" : "崔崔崔",
    "stars" : 4,
    "subscribed" : false,
    "uid" : "zFaFCZHPSuPwkT4XhqfjYFmSakJ3"
  },
  "zG5OYn6wz9XuEPhgMTN2gichTKX2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Rannie Saligumba",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zG5OYn6wz9XuEPhgMTN2gichTKX2"
  },
  "zGBBKaajYgfOUpyA3WwPQ6Mz7Z12" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zGBBKaajYgfOUpyA3WwPQ6Mz7Z12"
  },
  "zGHiHrvovZUZgpfYw0nhMrvkLF32" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Jian Fu",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zGHiHrvovZUZgpfYw0nhMrvkLF32"
  },
  "zGSkeA0AecOSQiSGK8f0KH8AoYE2" : {
    "bananas" : 1650,
    "lastDayPlayed" : "2018-04-05",
    "longestStreak" : 1,
    "name" : "Levi Hu",
    "stars" : 11,
    "subscribed" : false,
    "uid" : "zGSkeA0AecOSQiSGK8f0KH8AoYE2"
  },
  "zGr0mJvXUIT3y6biNL3dZO75J192" : {
    "bananas" : 2300,
    "lastDayPlayed" : "2019-02-07",
    "longestStreak" : 2,
    "name" : "Charlie Kempis",
    "stars" : 15,
    "subscribed" : false,
    "uid" : "zGr0mJvXUIT3y6biNL3dZO75J192"
  },
  "zGr67yPirkco79vTGGC1QDSZ4x03" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Khansa Silmi Kaffah",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zGr67yPirkco79vTGGC1QDSZ4x03"
  },
  "zGuZrvhx15MsX14BctMmOm1RMLk2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Slavomír Ondro",
    "stars" : 4,
    "subscribed" : false,
    "uid" : "zGuZrvhx15MsX14BctMmOm1RMLk2"
  },
  "zH2JJjxdKfY548lHPYeeF4Lkxll2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "程韬",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zH2JJjxdKfY548lHPYeeF4Lkxll2"
  },
  "zH4WDQZf44T3zy8pxgErEAHKCxO2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "ShinHyoung Joo",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zH4WDQZf44T3zy8pxgErEAHKCxO2"
  },
  "zHNPE7X22PPhuEa0de5xkwWr5Kh2" : {
    "bananas" : 1900,
    "lastDayPlayed" : "2018-08-24",
    "longestStreak" : 2,
    "name" : "Pham Duy Minh",
    "stars" : 12,
    "subscribed" : false,
    "uid" : "zHNPE7X22PPhuEa0de5xkwWr5Kh2"
  },
  "zHOw8fsRF6cyABBOCjWRbzaLRoC2" : {
    "bananas" : 800,
    "lastDayPlayed" : "2018-12-29",
    "longestStreak" : 1,
    "name" : "",
    "stars" : 8,
    "subscribed" : false,
    "uid" : "zHOw8fsRF6cyABBOCjWRbzaLRoC2"
  },
  "zHokvVRwUcMKGHHFCNmdGjmUQLH3" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "수범진",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zHokvVRwUcMKGHHFCNmdGjmUQLH3"
  },
  "zI0kuNIiOtYK4v65YdAuVEOG51Y2" : {
    "bananas" : 1450,
    "lastDayPlayed" : "2018-10-14",
    "longestStreak" : 1,
    "name" : "Jesse Gonzalez",
    "stars" : 8,
    "subscribed" : false,
    "uid" : "zI0kuNIiOtYK4v65YdAuVEOG51Y2"
  },
  "zI4YDfQ5FXfVk48dEqqlr4CQiTw2" : {
    "bananas" : 1400,
    "lastDayPlayed" : "2018-06-06",
    "longestStreak" : 2,
    "name" : "Ray Ong",
    "stars" : 9,
    "subscribed" : false,
    "uid" : "zI4YDfQ5FXfVk48dEqqlr4CQiTw2"
  },
  "zI4aHkI0szMk5eFAFxNgXnnHluA2" : {
    "bananas" : 350,
    "lastDayPlayed" : "2019-01-12",
    "longestStreak" : 1,
    "name" : "",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "zI4aHkI0szMk5eFAFxNgXnnHluA2"
  },
  "zI8TdPpA1lSL3bFy82gvpUB9dRL2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Ree V.R.",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zI8TdPpA1lSL3bFy82gvpUB9dRL2"
  },
  "zICAuYwAtahh4MdRT43qnauf2H43" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Kuntari Dasih",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zICAuYwAtahh4MdRT43qnauf2H43"
  },
  "zIF4uId7QOMWxs2qEgaM3s51kk53" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Queen of Jams",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zIF4uId7QOMWxs2qEgaM3s51kk53"
  },
  "zIJRzvb7pIY9U0HWQilQTgrciVp2" : {
    "bananas" : 300,
    "lastDayPlayed" : "2018-04-14",
    "longestStreak" : 1,
    "name" : "趙英渝",
    "stars" : 4,
    "subscribed" : false,
    "uid" : "zIJRzvb7pIY9U0HWQilQTgrciVp2"
  },
  "zIcuVjS7HVUZ7xXL6mEVAXhfwf83" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Amiey Mohamad",
    "stars" : 0,
    "subscribed" : false,
    "uid" : "zIcuVjS7HVUZ7xXL6mEVAXhfwf83"
  },
  "zIuUTLc10jdvp1RAmK21OFv0Jas1" : {
    "bananas" : 2550,
    "lastDayPlayed" : "2018-12-29",
    "longestStreak" : 1,
    "name" : "Husna Latif",
    "stars" : 10,
    "subscribed" : false,
    "uid" : "zIuUTLc10jdvp1RAmK21OFv0Jas1"
  },
  "zJAwocLdNqV8zZYTWLHIe4kXS023" : {
    "bananas" : 800,
    "lastDayPlayed" : "2018-10-07",
    "longestStreak" : 1,
    "name" : "Erik Petersen",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zJAwocLdNqV8zZYTWLHIe4kXS023"
  },
  "zJXU0vvKtOZTBtdGCpF7DETyFXt2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Thuý Đa",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zJXU0vvKtOZTBtdGCpF7DETyFXt2"
  },
  "zJZCVjAwLFNBaPch3JdrNvDktWn1" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Galvyn Chow",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zJZCVjAwLFNBaPch3JdrNvDktWn1"
  },
  "zJd07kcIKWOKmd93CLriha2Oavl2" : {
    "bananas" : 200,
    "lastDayPlayed" : "2018-10-02",
    "longestStreak" : 1,
    "name" : "P B",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "zJd07kcIKWOKmd93CLriha2Oavl2"
  },
  "zJrdlsqpVXeFdH2dpCqstY2qpcn2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Dang Nhan",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zJrdlsqpVXeFdH2dpCqstY2qpcn2"
  },
  "zJsI8m74uqOI3el3EM1u64kbUWd2" : {
    "bananas" : 36750,
    "lastDayPlayed" : "2018-07-21",
    "longestStreak" : 18,
    "name" : "Chris Buckley",
    "stars" : 176,
    "subscribed" : true,
    "uid" : "zJsI8m74uqOI3el3EM1u64kbUWd2"
  },
  "zJwSgKip9kRVcRjSITq4lqTpWdu1" : {
    "bananas" : 3500,
    "lastDayPlayed" : "2019-01-13",
    "longestStreak" : 2,
    "name" : "SmoKing500",
    "stars" : 21,
    "subscribed" : false,
    "uid" : "zJwSgKip9kRVcRjSITq4lqTpWdu1"
  },
  "zJxYshgB1kQKDh3YWYSulBJaD9j1" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "anis adnan",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zJxYshgB1kQKDh3YWYSulBJaD9j1"
  },
  "zK4b2oA3RtNc17tmhgOXtFtowmj2" : {
    "bananas" : 400,
    "lastDayPlayed" : "2018-08-02",
    "longestStreak" : 1,
    "name" : "Alan Au",
    "stars" : 7,
    "subscribed" : false,
    "uid" : "zK4b2oA3RtNc17tmhgOXtFtowmj2"
  },
  "zKAY3Szf5OOJp91wl9aryqxGlcB3" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Dekel Biniamini",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zKAY3Szf5OOJp91wl9aryqxGlcB3"
  },
  "zKBUVLdFl1U1BPVlPjNCxcmmc8d2" : {
    "bananas" : 350,
    "lastDayPlayed" : "2018-04-08",
    "longestStreak" : 1,
    "name" : "Radiance Choo",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "zKBUVLdFl1U1BPVlPjNCxcmmc8d2"
  },
  "zKKayNTJTtX0ZgB1lofcRmB7mR02" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "wenlan wang",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zKKayNTJTtX0ZgB1lofcRmB7mR02"
  },
  "zKXYNEauePg0xmrt7qh3WRCnaI13" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Hien Dong",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zKXYNEauePg0xmrt7qh3WRCnaI13"
  },
  "zKbiDxyn9je7BKZSxKta8tMF2Ej2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "TONY YU",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zKbiDxyn9je7BKZSxKta8tMF2Ej2"
  },
  "zKhwgOO4oxTDgLnp7QVRyVmHSs52" : {
    "bananas" : 500,
    "lastDayPlayed" : "2018-07-19",
    "longestStreak" : 1,
    "name" : "DICK NG",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zKhwgOO4oxTDgLnp7QVRyVmHSs52"
  },
  "zKzINOTR5thnGXqQBn7nCfaNdrk1" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Michael Jak",
    "stars" : 0,
    "subscribed" : false,
    "uid" : "zKzINOTR5thnGXqQBn7nCfaNdrk1"
  },
  "zLCrcse9mORX55gQvDuA3aPqkCk2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "setven yap",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zLCrcse9mORX55gQvDuA3aPqkCk2"
  },
  "zLQewEqgirTGK4P4Fn4qW8dbR4l2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "AJ Caloza",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zLQewEqgirTGK4P4Fn4qW8dbR4l2"
  },
  "zLWdOBsFsebwGbvBkxTJdyobC6C2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "张译",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zLWdOBsFsebwGbvBkxTJdyobC6C2"
  },
  "zLYinz5lkoaurRotKJKokygFrRF3" : {
    "bananas" : 200,
    "lastDayPlayed" : "2019-01-11",
    "longestStreak" : 1,
    "name" : "valentina keisham",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "zLYinz5lkoaurRotKJKokygFrRF3"
  },
  "zLdEHuDuhocowsb9QbZAVnUAjVC2" : {
    "bananas" : 550,
    "lastDayPlayed" : "2018-07-31",
    "longestStreak" : 1,
    "name" : "Снежный Лис",
    "stars" : 7,
    "subscribed" : false,
    "uid" : "zLdEHuDuhocowsb9QbZAVnUAjVC2"
  },
  "zLgRJcqWC4eG1SCpqimIiIaALQv2" : {
    "bananas" : 300,
    "lastDayPlayed" : "2018-09-30",
    "longestStreak" : 1,
    "name" : "Shania Christina Westy",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zLgRJcqWC4eG1SCpqimIiIaALQv2"
  },
  "zLlxeBk5X1RGxyyBaLpTqJ77X433" : {
    "bananas" : 5900,
    "lastDayPlayed" : "2018-07-12",
    "longestStreak" : 5,
    "name" : "LI Fei",
    "stars" : 23,
    "subscribed" : false,
    "uid" : "zLlxeBk5X1RGxyyBaLpTqJ77X433"
  },
  "zLuptOs5wSQLsypAlmcgvgI4BP32" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Felipe Mica",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zLuptOs5wSQLsypAlmcgvgI4BP32"
  },
  "zLv6C6sUCGZkPzMc8VDKKOtVXuq2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Catalina Muñoz Barrientos",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zLv6C6sUCGZkPzMc8VDKKOtVXuq2"
  },
  "zMLJQx3m37TMuLiiEANvoiv1Hme2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Hai Vu",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zMLJQx3m37TMuLiiEANvoiv1Hme2"
  },
  "zMMRlxJ3PpQTYav5grtrAFaGu6q1" : {
    "bananas" : 1200,
    "lastDayPlayed" : "2018-07-27",
    "longestStreak" : 1,
    "name" : "黄家正",
    "stars" : 10,
    "subscribed" : false,
    "uid" : "zMMRlxJ3PpQTYav5grtrAFaGu6q1"
  },
  "zMWjnTK6aVMFkMIDXkHFivDWf8D3" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Martinus Putera",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zMWjnTK6aVMFkMIDXkHFivDWf8D3"
  },
  "zMX3YaQJAdfxV7yooU8ghtTq6g43" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Ben Kelly",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zMX3YaQJAdfxV7yooU8ghtTq6g43"
  },
  "zMtWeaaEQjZL5IN8PrrcgAmPXVG3" : {
    "bananas" : 200,
    "lastDayPlayed" : "2018-09-14",
    "longestStreak" : 1,
    "name" : "A B",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "zMtWeaaEQjZL5IN8PrrcgAmPXVG3"
  },
  "zN4Pm5NhDMMEHKbLXu7OZs2pYVv2" : {
    "bananas" : 1750,
    "lastDayPlayed" : "2018-12-16",
    "longestStreak" : 1,
    "name" : "Caitlyn",
    "stars" : 12,
    "subscribed" : false,
    "uid" : "zN4Pm5NhDMMEHKbLXu7OZs2pYVv2"
  },
  "zN8bL9jWO1V4i1cZKP69A5nWd4s2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "علي ابراهيم",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zN8bL9jWO1V4i1cZKP69A5nWd4s2"
  },
  "zNGGIF3qVIMlD82iOpRU5ACYp8J2" : {
    "bananas" : 800,
    "lastDayPlayed" : "2018-10-27",
    "longestStreak" : 2,
    "name" : "Beryl Tan Yun Xuan",
    "stars" : 9,
    "subscribed" : false,
    "uid" : "zNGGIF3qVIMlD82iOpRU5ACYp8J2"
  },
  "zNHtdGIRiYTUkWxiTiUUCcGQbrg1" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Jozen Kuah",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zNHtdGIRiYTUkWxiTiUUCcGQbrg1"
  },
  "zNWZPaLzzeRqFNCGma8hoA4aYLW2" : {
    "bananas" : 300,
    "lastDayPlayed" : "2018-12-30",
    "longestStreak" : 2,
    "name" : "Anthony Chen",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "zNWZPaLzzeRqFNCGma8hoA4aYLW2"
  },
  "zOBey4tG5WWbykSiCH1CcZ2ONdI2" : {
    "bananas" : 200,
    "lastDayPlayed" : "2018-09-17",
    "longestStreak" : 1,
    "name" : "Angel Lim",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "zOBey4tG5WWbykSiCH1CcZ2ONdI2"
  },
  "zOCMOcl3dKfgnJFvaS1Tk9Ifq3A3" : {
    "bananas" : 11250,
    "lastDayPlayed" : "2019-01-29",
    "longestStreak" : 4,
    "name" : "Lawrence Chan",
    "stars" : 53,
    "subscribed" : true,
    "uid" : "zOCMOcl3dKfgnJFvaS1Tk9Ifq3A3"
  },
  "zOFbVe77EfXFcktmpVbrWBJ35ei1" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "William Cook",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zOFbVe77EfXFcktmpVbrWBJ35ei1"
  },
  "zOGjEKyWpmTZhv60RVxxw6OJbig2" : {
    "bananas" : 550,
    "lastDayPlayed" : "2018-09-28",
    "longestStreak" : 3,
    "name" : "Aliece Angell",
    "stars" : 7,
    "subscribed" : false,
    "uid" : "zOGjEKyWpmTZhv60RVxxw6OJbig2"
  },
  "zOKzuWGBUVWRrTxyEHgTKc4gin32" : {
    "bananas" : 6200,
    "lastDayPlayed" : "2018-12-23",
    "longestStreak" : 2,
    "name" : "Alexander Mochalski",
    "stars" : 26,
    "subscribed" : true,
    "uid" : "zOKzuWGBUVWRrTxyEHgTKc4gin32"
  },
  "zOT2HhmzJnSv7TFS2R4psgRkcYa2" : {
    "bananas" : 400,
    "lastDayPlayed" : "2019-01-08",
    "longestStreak" : 1,
    "name" : "Anthony Lisak",
    "stars" : 7,
    "subscribed" : false,
    "uid" : "zOT2HhmzJnSv7TFS2R4psgRkcYa2"
  },
  "zOkoatF19QU1f940h0aInWAgHBh1" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Arth Bima",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zOkoatF19QU1f940h0aInWAgHBh1"
  },
  "zOlFL1qXE4caH2J7nJVqcw0YvRH3" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "virginia aurelia",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zOlFL1qXE4caH2J7nJVqcw0YvRH3"
  },
  "zOoCrjyLMVZkh4vTfw2v1NE1iHu1" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Sue Ann",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zOoCrjyLMVZkh4vTfw2v1NE1iHu1"
  },
  "zOztg0xHJwN2GSHO9XSFAPvTl7E2" : {
    "bananas" : 27800,
    "lastDayPlayed" : "2018-12-30",
    "longestStreak" : 7,
    "name" : "Patrick Kennedy",
    "stars" : 104,
    "subscribed" : true,
    "uid" : "zOztg0xHJwN2GSHO9XSFAPvTl7E2"
  },
  "zPWOJtKXT7b6I4LA5Yfh1YlZBog1" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Kyle Goodwin",
    "stars" : 0,
    "subscribed" : false,
    "uid" : "zPWOJtKXT7b6I4LA5Yfh1YlZBog1"
  },
  "zPctgFebBPMzQRsWoglpcdJsn052" : {
    "bananas" : 1700,
    "lastDayPlayed" : "2018-10-15",
    "longestStreak" : 1,
    "name" : "Abigail Kirkbride",
    "stars" : 10,
    "subscribed" : false,
    "uid" : "zPctgFebBPMzQRsWoglpcdJsn052"
  },
  "zPtciIUpjbWsrQ7Pw3xDiJWk6r22" : {
    "bananas" : 500,
    "lastDayPlayed" : "2018-10-14",
    "longestStreak" : 1,
    "name" : "ကာ လီ ကို",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "zPtciIUpjbWsrQ7Pw3xDiJWk6r22"
  },
  "zQ4lspp12aMTh9PyiqdrfxzQpv82" : {
    "bananas" : 2050,
    "lastDayPlayed" : "2018-09-02",
    "longestStreak" : 1,
    "name" : "Maass Martha",
    "stars" : 8,
    "subscribed" : false,
    "uid" : "zQ4lspp12aMTh9PyiqdrfxzQpv82"
  },
  "zQAiRxlPXrMmvjrscwmEHDuNQ942" : {
    "bananas" : 200,
    "lastDayPlayed" : "2018-05-16",
    "longestStreak" : 1,
    "name" : "nick Koay",
    "stars" : 4,
    "subscribed" : false,
    "uid" : "zQAiRxlPXrMmvjrscwmEHDuNQ942"
  },
  "zQEewfi1FvNNuSPKdgIU4Ke4lS32" : {
    "bananas" : 750,
    "lastDayPlayed" : "2018-10-13",
    "longestStreak" : 1,
    "name" : "Ah Teck",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zQEewfi1FvNNuSPKdgIU4Ke4lS32"
  },
  "zQH10NTZfYaXACdiF3V6hd7Ahn93" : {
    "bananas" : 19500,
    "lastDayPlayed" : "2019-02-02",
    "longestStreak" : 9,
    "name" : "Wolfgang Wirtz",
    "stars" : 92,
    "subscribed" : true,
    "uid" : "zQH10NTZfYaXACdiF3V6hd7Ahn93"
  },
  "zQHqAv92CPNkIHAE1W9zxHfhTn92" : {
    "bananas" : 2750,
    "lastDayPlayed" : "2018-10-05",
    "longestStreak" : 2,
    "name" : "David Deluca",
    "stars" : 17,
    "subscribed" : false,
    "uid" : "zQHqAv92CPNkIHAE1W9zxHfhTn92"
  },
  "zQZEYd9XNGggvGd5f598YLDFpYP2" : {
    "bananas" : 200,
    "lastDayPlayed" : "2018-09-09",
    "longestStreak" : 1,
    "name" : "Raisa Ahmed",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "zQZEYd9XNGggvGd5f598YLDFpYP2"
  },
  "zQrMB9icJLWED4wB9or4RMz14gG2" : {
    "bananas" : 1250,
    "lastDayPlayed" : "2018-05-09",
    "longestStreak" : 1,
    "name" : "Magnus Nilsson",
    "stars" : 9,
    "subscribed" : false,
    "uid" : "zQrMB9icJLWED4wB9or4RMz14gG2"
  },
  "zQwozqzl6oMAjMcB9jcKWYaq2U43" : {
    "bananas" : 1350,
    "lastDayPlayed" : "2018-04-26",
    "longestStreak" : 3,
    "name" : "황위정",
    "stars" : 9,
    "subscribed" : false,
    "uid" : "zQwozqzl6oMAjMcB9jcKWYaq2U43"
  },
  "zQxkk8EsWYd7HVJ0ahedDjeCMM53" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Deviana Anggraini",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zQxkk8EsWYd7HVJ0ahedDjeCMM53"
  },
  "zR1E2SDs2If6cBThAx97lDsnVPG3" : {
    "bananas" : 950,
    "lastDayPlayed" : "2019-01-06",
    "longestStreak" : 1,
    "name" : "Cody Mattingly",
    "stars" : 9,
    "subscribed" : false,
    "uid" : "zR1E2SDs2If6cBThAx97lDsnVPG3"
  },
  "zRC7GU6alOTXW94wUWJt5jZaHgz2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "deen omar",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zRC7GU6alOTXW94wUWJt5jZaHgz2"
  },
  "zRa6fy2hvtYWXkKI3jKoASOqmd32" : {
    "bananas" : 8300,
    "lastDayPlayed" : "2019-01-25",
    "longestStreak" : 4,
    "name" : "Hannah Krzywicki",
    "stars" : 34,
    "subscribed" : true,
    "uid" : "zRa6fy2hvtYWXkKI3jKoASOqmd32"
  },
  "zRfDydbQCWTaG6d0NJtj4ToJJnG3" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Win Thu",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zRfDydbQCWTaG6d0NJtj4ToJJnG3"
  },
  "zRkRzsJkq3QNBn5Xdz0lKlqCV5D2" : {
    "bananas" : 400,
    "lastDayPlayed" : "2018-10-17",
    "longestStreak" : 1,
    "name" : "Leo Hi",
    "stars" : 7,
    "subscribed" : false,
    "uid" : "zRkRzsJkq3QNBn5Xdz0lKlqCV5D2"
  },
  "zRqqwaDC6vh2z0cvv5IDGV26r2H2" : {
    "bananas" : 750,
    "lastDayPlayed" : "2018-11-20",
    "longestStreak" : 1,
    "name" : "Thilo",
    "stars" : 8,
    "subscribed" : false,
    "uid" : "zRqqwaDC6vh2z0cvv5IDGV26r2H2"
  },
  "zRvuxmo3BDXIozG7W4np2glYsct1" : {
    "bananas" : 200,
    "lastDayPlayed" : "2018-11-28",
    "longestStreak" : 1,
    "name" : "Andrea Jones",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "zRvuxmo3BDXIozG7W4np2glYsct1"
  },
  "zS30iGvPtNhIjywkOdv5bZpd4fp1" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zS30iGvPtNhIjywkOdv5bZpd4fp1"
  },
  "zSDDclV6EvQWMRHyVWfF17INtDw2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Win Shwe",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zSDDclV6EvQWMRHyVWfF17INtDw2"
  },
  "zSSZ7xXHC8fq0KsLRzsQOf7Qgww1" : {
    "bananas" : 500,
    "lastDayPlayed" : "2018-05-17",
    "longestStreak" : 1,
    "name" : "Thomas Smith",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zSSZ7xXHC8fq0KsLRzsQOf7Qgww1"
  },
  "zSvyE4MxRaPrIC3mGTWmwCbwogz1" : {
    "bananas" : 600,
    "lastDayPlayed" : "2018-12-11",
    "longestStreak" : 1,
    "name" : "Andrayaa Averyy",
    "stars" : 7,
    "subscribed" : false,
    "uid" : "zSvyE4MxRaPrIC3mGTWmwCbwogz1"
  },
  "zT75hF7aOCdPsEaU5tdHrVH9zDy2" : {
    "bananas" : 200,
    "lastDayPlayed" : "2018-09-15",
    "longestStreak" : 1,
    "name" : "Maou Kai",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "zT75hF7aOCdPsEaU5tdHrVH9zDy2"
  },
  "zT7kG3FtAISfJm51kbOvMIbLAsB2" : {
    "bananas" : 150,
    "lastDayPlayed" : "2019-01-31",
    "longestStreak" : 1,
    "name" : "Isabell Hartih",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zT7kG3FtAISfJm51kbOvMIbLAsB2"
  },
  "zTS52kVamBgVt58lw1XqZsPTRL72" : {
    "bananas" : 2300,
    "lastDayPlayed" : "2018-12-10",
    "longestStreak" : 2,
    "name" : "ridha fatima",
    "stars" : 15,
    "subscribed" : false,
    "uid" : "zTS52kVamBgVt58lw1XqZsPTRL72"
  },
  "zTbYx51ITTZ1YIUF9htjsWNz0wd2" : {
    "bananas" : 550,
    "lastDayPlayed" : "2018-09-14",
    "longestStreak" : 1,
    "name" : "Sanjay Jegatheesan",
    "stars" : 7,
    "subscribed" : false,
    "uid" : "zTbYx51ITTZ1YIUF9htjsWNz0wd2"
  },
  "zTeJqnuxBXaL4tnZSjhnJCTpfcq2" : {
    "bananas" : 400,
    "lastDayPlayed" : "2018-08-06",
    "longestStreak" : 1,
    "name" : "",
    "stars" : 7,
    "subscribed" : false,
    "uid" : "zTeJqnuxBXaL4tnZSjhnJCTpfcq2"
  },
  "zU6sDK44MPTVxoMZQXvZUfkhbqs1" : {
    "bananas" : 5400,
    "lastDayPlayed" : "2019-02-01",
    "longestStreak" : 4,
    "name" : "James Edmans",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zU6sDK44MPTVxoMZQXvZUfkhbqs1"
  },
  "zUK9LP7nA3PQkXOcdvrY7Y0av5o1" : {
    "bananas" : 300,
    "lastDayPlayed" : "2019-01-17",
    "longestStreak" : 1,
    "name" : "Pahnno Yep",
    "stars" : 4,
    "subscribed" : false,
    "uid" : "zUK9LP7nA3PQkXOcdvrY7Y0av5o1"
  },
  "zUMl5ddC5UbiXCatPEkNnb6c13S2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Thomas Malm",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zUMl5ddC5UbiXCatPEkNnb6c13S2"
  },
  "zUxEUspgw8ZJ9E2WCawV2hhsS1B2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "cik yan",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zUxEUspgw8ZJ9E2WCawV2hhsS1B2"
  },
  "zV0CUgyQl2bqFpna5UrYPml6fvv1" : {
    "bananas" : 150,
    "lastDayPlayed" : "2019-01-10",
    "longestStreak" : 1,
    "name" : "bernard vyncke",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zV0CUgyQl2bqFpna5UrYPml6fvv1"
  },
  "zVOz7vTC7OPs3o1i8KjcmSs1Vr62" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zVOz7vTC7OPs3o1i8KjcmSs1Vr62"
  },
  "zVnUWYbYFVXD3XkJfB0WfjFYEAs1" : {
    "bananas" : 1150,
    "lastDayPlayed" : "2018-07-01",
    "longestStreak" : 1,
    "name" : "Nur Safiah",
    "stars" : 8,
    "subscribed" : false,
    "uid" : "zVnUWYbYFVXD3XkJfB0WfjFYEAs1"
  },
  "zWBhI5DGOue0AthFkYJmW5TUtcf2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "王文韬",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zWBhI5DGOue0AthFkYJmW5TUtcf2"
  },
  "zWGH5KOdNIYi5By0y2g4VyjEvZr1" : {
    "bananas" : 200,
    "lastDayPlayed" : "2018-07-22",
    "longestStreak" : 1,
    "name" : "Beaut Phukan Baruah",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "zWGH5KOdNIYi5By0y2g4VyjEvZr1"
  },
  "zWK5IYwCegT1TvDi0EGfrjRnFKu2" : {
    "bananas" : 1450,
    "lastDayPlayed" : "2018-07-08",
    "longestStreak" : 1,
    "name" : "Ocren Nakros",
    "stars" : 10,
    "subscribed" : false,
    "uid" : "zWK5IYwCegT1TvDi0EGfrjRnFKu2"
  },
  "zWPzss20Xpecs9tpiAESFOzNlpc2" : {
    "bananas" : 2100,
    "lastDayPlayed" : "2018-06-24",
    "longestStreak" : 1,
    "name" : "Muhammad Aizam",
    "stars" : 8,
    "subscribed" : false,
    "uid" : "zWPzss20Xpecs9tpiAESFOzNlpc2"
  },
  "zWUNAGikuSXtKBYE7S9QRDfCb213" : {
    "bananas" : 2750,
    "lastDayPlayed" : "2019-01-28",
    "longestStreak" : 1,
    "name" : "",
    "stars" : 18,
    "subscribed" : false,
    "uid" : "zWUNAGikuSXtKBYE7S9QRDfCb213"
  },
  "zWiAkiP4xagr4IxcBVmPbaZHSjx2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "심행섭",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zWiAkiP4xagr4IxcBVmPbaZHSjx2"
  },
  "zXCjkTO8pXeNHZ3RHdIhrz6AfP33" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "IDK LIFE",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zXCjkTO8pXeNHZ3RHdIhrz6AfP33"
  },
  "zXO2s8Ecv6RJ5QCryErIUzYY3DG2" : {
    "bananas" : 450,
    "lastDayPlayed" : "2018-11-22",
    "longestStreak" : 1,
    "name" : "YenYen Tan",
    "stars" : 4,
    "subscribed" : false,
    "uid" : "zXO2s8Ecv6RJ5QCryErIUzYY3DG2"
  },
  "zXd2QaxtQiXcmDfsZcWmCQVorR23" : {
    "bananas" : 600,
    "lastDayPlayed" : "2019-01-27",
    "longestStreak" : 1,
    "name" : "",
    "stars" : 8,
    "subscribed" : false,
    "uid" : "zXd2QaxtQiXcmDfsZcWmCQVorR23"
  },
  "zY4BRhqbznboVOwBuEeLNJI0VN12" : {
    "bananas" : 200,
    "lastDayPlayed" : "2018-12-19",
    "longestStreak" : 1,
    "name" : "huayun ma",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "zY4BRhqbznboVOwBuEeLNJI0VN12"
  },
  "zY7Ncew5ljQOb1nac0MkwvZ9r4n1" : {
    "bananas" : 100,
    "lastDayPlayed" : "2018-11-05",
    "longestStreak" : 1,
    "name" : "Roger Eriksen",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zY7Ncew5ljQOb1nac0MkwvZ9r4n1"
  },
  "zYHs2HIne6huhfoHTdJqKV0RwAc2" : {
    "bananas" : 150,
    "lastDayPlayed" : "2018-12-20",
    "longestStreak" : 1,
    "name" : "",
    "stars" : 3,
    "subscribed" : false,
    "uid" : "zYHs2HIne6huhfoHTdJqKV0RwAc2"
  },
  "zYPGJUJV3wY1jANnWacpxwsD7FJ2" : {
    "bananas" : 4300,
    "lastDayPlayed" : "2018-10-31",
    "longestStreak" : 8,
    "name" : "Will Gao",
    "stars" : 21,
    "subscribed" : false,
    "uid" : "zYPGJUJV3wY1jANnWacpxwsD7FJ2"
  },
  "zYhHwn10AZUrIfheY7AbmngJrts1" : {
    "bananas" : 1700,
    "lastDayPlayed" : "2019-02-10",
    "longestStreak" : 2,
    "name" : "Ben Bryan",
    "stars" : 9,
    "subscribed" : false,
    "uid" : "zYhHwn10AZUrIfheY7AbmngJrts1"
  },
  "zYp2Ll5UIUV1tCQogbvZdaTiqnz1" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "John Shin",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zYp2Ll5UIUV1tCQogbvZdaTiqnz1"
  },
  "zZ5d4I5W9DMD49UD7XPHwnIU0BI2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Kristi",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zZ5d4I5W9DMD49UD7XPHwnIU0BI2"
  },
  "zZ6B1PYdfLTrNpkV2DJ29rt1NNl1" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Galaxy Girl",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zZ6B1PYdfLTrNpkV2DJ29rt1NNl1"
  },
  "zZ85qbs9LvT55fdqEVc2JL4EOnh1" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "E H H P U T R A A Q I L IX",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zZ85qbs9LvT55fdqEVc2JL4EOnh1"
  },
  "zZCH3A12NpW3NSbEHc6SDLT5jLf1" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Thok Leap Heng",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zZCH3A12NpW3NSbEHc6SDLT5jLf1"
  },
  "zZTD2HBl0afKeHy7cq7Grmh789S2" : {
    "bananas" : 150,
    "lastDayPlayed" : "2018-12-25",
    "longestStreak" : 1,
    "name" : "CmVsUzUkI CmV",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zZTD2HBl0afKeHy7cq7Grmh789S2"
  },
  "zZXSjas7BigmEk1NdO5CwJhoqtB2" : {
    "bananas" : 400,
    "lastDayPlayed" : "2019-01-21",
    "longestStreak" : 1,
    "name" : "",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zZXSjas7BigmEk1NdO5CwJhoqtB2"
  },
  "zZaolvrNMOVsZyrpVa7uS703x5m2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Kaitlyn Peace",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zZaolvrNMOVsZyrpVa7uS703x5m2"
  },
  "zZchLvjDn6VZ0ToFxHbRwibINsC2" : {
    "bananas" : 2050,
    "lastDayPlayed" : "2018-11-28",
    "longestStreak" : 1,
    "name" : "Jessica Langford",
    "stars" : 12,
    "subscribed" : false,
    "uid" : "zZchLvjDn6VZ0ToFxHbRwibINsC2"
  },
  "zZlPCfxxrURb3943SS8H1CO2n6B3" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "tommy",
    "stars" : 5,
    "subscribed" : true,
    "uid" : "zZlPCfxxrURb3943SS8H1CO2n6B3"
  },
  "zZslrtbGXsW9MiDOtTKOGARBiYw2" : {
    "bananas" : 3150,
    "lastDayPlayed" : "2018-09-05",
    "longestStreak" : 5,
    "name" : "li Choi",
    "stars" : 17,
    "subscribed" : false,
    "uid" : "zZslrtbGXsW9MiDOtTKOGARBiYw2"
  },
  "za4RO2QU33bFTtMjOtKl4zoYJH82" : {
    "bananas" : 600,
    "lastDayPlayed" : "2019-01-13",
    "longestStreak" : 1,
    "name" : "강보연",
    "stars" : 8,
    "subscribed" : false,
    "uid" : "za4RO2QU33bFTtMjOtKl4zoYJH82"
  },
  "zaOFZh3nRsPYGn9mz2OousEtlf92" : {
    "bananas" : 350,
    "lastDayPlayed" : "2018-08-10",
    "longestStreak" : 1,
    "name" : "Ja'kayla Baker",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zaOFZh3nRsPYGn9mz2OousEtlf92"
  },
  "zaOzvAEHgre8S2olYNfW4KlqbzQ2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zaOzvAEHgre8S2olYNfW4KlqbzQ2"
  },
  "zaQ5tha7YgYkpkfEVbDFJxdEAlq2" : {
    "bananas" : 1800,
    "lastDayPlayed" : "2018-04-17",
    "longestStreak" : 1,
    "name" : "Max Williams",
    "stars" : 14,
    "subscribed" : true,
    "uid" : "zaQ5tha7YgYkpkfEVbDFJxdEAlq2"
  },
  "zaiC2Tbl1KPeAuqZCyzCaYKfifl2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Kaan Aytekin",
    "stars" : 4,
    "subscribed" : false,
    "uid" : "zaiC2Tbl1KPeAuqZCyzCaYKfifl2"
  },
  "zauU890VQpRtH8bTLWIPMbf1ne42" : {
    "bananas" : 300,
    "lastDayPlayed" : "2018-12-08",
    "longestStreak" : 1,
    "name" : "Trevor Isaac",
    "stars" : 4,
    "subscribed" : false,
    "uid" : "zauU890VQpRtH8bTLWIPMbf1ne42"
  },
  "zauxp6KTucRpzvy5MsYxKidT2HO2" : {
    "bananas" : 550,
    "lastDayPlayed" : "2018-11-06",
    "longestStreak" : 1,
    "name" : "",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "zauxp6KTucRpzvy5MsYxKidT2HO2"
  },
  "zayhZbpkubUaYzQ1nc50ZUkpPh42" : {
    "bananas" : 3450,
    "lastDayPlayed" : "2018-09-02",
    "longestStreak" : 1,
    "name" : "ឡាំ អរុណ",
    "stars" : 18,
    "subscribed" : false,
    "uid" : "zayhZbpkubUaYzQ1nc50ZUkpPh42"
  },
  "zazmCwX1X2YmUaLk8VyeVco4Ffq2" : {
    "bananas" : 200,
    "lastDayPlayed" : "2018-05-21",
    "longestStreak" : 1,
    "name" : "Aramis Yang",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zazmCwX1X2YmUaLk8VyeVco4Ffq2"
  },
  "zb6n0pAPiIa72nI3R5tqa502Y2q1" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Bình Nguyễn",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zb6n0pAPiIa72nI3R5tqa502Y2q1"
  },
  "zbF2NYNSrlWbmXL0RRQxlSq2q9e2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Ari Torres",
    "stars" : 5,
    "subscribed" : true,
    "uid" : "zbF2NYNSrlWbmXL0RRQxlSq2q9e2"
  },
  "zbLJwTMQDcYnJX0V8OhQ1ABORn43" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Khant Lin Sam",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zbLJwTMQDcYnJX0V8OhQ1ABORn43"
  },
  "zbfLNxJifFUm8KYVnmmKIQ7s52u1" : {
    "bananas" : 150,
    "lastDayPlayed" : "2018-08-15",
    "longestStreak" : 1,
    "name" : "lerona pem",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zbfLNxJifFUm8KYVnmmKIQ7s52u1"
  },
  "zbsidJ4UQ2Vk2VzEkNtA9Saes1i2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "mahee thehuman",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zbsidJ4UQ2Vk2VzEkNtA9Saes1i2"
  },
  "zbvHNGMUZBPHhrbyeNIcctrGzih1" : {
    "bananas" : 1200,
    "lastDayPlayed" : "2018-12-06",
    "longestStreak" : 1,
    "name" : "Muhammad Rizqi Kurniadi",
    "stars" : 9,
    "subscribed" : false,
    "uid" : "zbvHNGMUZBPHhrbyeNIcctrGzih1"
  },
  "zcCcOlHtboSQ3fwICpVepqQlkm93" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "daniel feddersen",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zcCcOlHtboSQ3fwICpVepqQlkm93"
  },
  "zcCeraxRtBYLosTVaQBcTL5h2ny2" : {
    "bananas" : 150,
    "lastDayPlayed" : "2018-11-05",
    "longestStreak" : 1,
    "name" : "Gary Lim",
    "stars" : 4,
    "subscribed" : false,
    "uid" : "zcCeraxRtBYLosTVaQBcTL5h2ny2"
  },
  "zcULbtEmDJg14t8XlfRslWikwfh2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Sai Myint",
    "stars" : 4,
    "subscribed" : false,
    "uid" : "zcULbtEmDJg14t8XlfRslWikwfh2"
  },
  "zcXlyrVQPoVHo6Tq41UpkLgWi3U2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "L Park",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zcXlyrVQPoVHo6Tq41UpkLgWi3U2"
  },
  "zcY67ZtXboZE4qaHNYagDVxyDIi2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Kali Gladdish",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zcY67ZtXboZE4qaHNYagDVxyDIi2"
  },
  "zcaao084uXVWMHnJe9vtI9N4Yhc2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Pierre Carreira",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zcaao084uXVWMHnJe9vtI9N4Yhc2"
  },
  "zciubUNL2MThbVdMZfTbIo0tibh1" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "John Clarke",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zciubUNL2MThbVdMZfTbIo0tibh1"
  },
  "zcpoytOjNGgA0tHSKcVdi6sMLZ72" : {
    "bananas" : 800,
    "lastDayPlayed" : "2018-09-18",
    "longestStreak" : 1,
    "name" : "",
    "stars" : 9,
    "subscribed" : false,
    "uid" : "zcpoytOjNGgA0tHSKcVdi6sMLZ72"
  },
  "zcwBLvrzzmd0euqT9JbaRXbLTOd2" : {
    "bananas" : 300,
    "lastDayPlayed" : "2018-11-06",
    "longestStreak" : 1,
    "name" : "Hninyu Hlaing Aye",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zcwBLvrzzmd0euqT9JbaRXbLTOd2"
  },
  "zcx9vIKIvrUXdPd7sBdldeyTjAE3" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "สวนมะลิ ฝู พร้าว",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zcx9vIKIvrUXdPd7sBdldeyTjAE3"
  },
  "zd3FsnKRmpd8fSI4AwqlLtUtxE12" : {
    "bananas" : 400,
    "lastDayPlayed" : "2018-12-08",
    "longestStreak" : 1,
    "name" : "James Tompkins",
    "stars" : 7,
    "subscribed" : false,
    "uid" : "zd3FsnKRmpd8fSI4AwqlLtUtxE12"
  },
  "zd3ummBFI7c0BVdtoMWIj2jWr132" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zd3ummBFI7c0BVdtoMWIj2jWr132"
  },
  "zdP6H705EDduSypLwd8H7hNJ7dn2" : {
    "bananas" : 300,
    "lastDayPlayed" : "2018-09-19",
    "longestStreak" : 1,
    "name" : "",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zdP6H705EDduSypLwd8H7hNJ7dn2"
  },
  "zdTqbp6rT1cuPpxfYqa1ec70dGm2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Ina Peneva",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zdTqbp6rT1cuPpxfYqa1ec70dGm2"
  },
  "zdUOGBiRneeR8IEi1ylLEOxcUsG3" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Manuel Ferreira",
    "stars" : 4,
    "subscribed" : false,
    "uid" : "zdUOGBiRneeR8IEi1ylLEOxcUsG3"
  },
  "zdba6S0iAnZH5Q79QKbQ5U8CBds2" : {
    "bananas" : 150,
    "lastDayPlayed" : "2018-06-27",
    "longestStreak" : 1,
    "name" : "arumi syazwanee",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zdba6S0iAnZH5Q79QKbQ5U8CBds2"
  },
  "zdfxKWbOeYffQJ0fFjrcHswIqbj1" : {
    "bananas" : 400,
    "lastDayPlayed" : "2019-01-26",
    "longestStreak" : 1,
    "name" : "Grace X",
    "stars" : 7,
    "subscribed" : false,
    "uid" : "zdfxKWbOeYffQJ0fFjrcHswIqbj1"
  },
  "zdtY3H5wL6TIUnrc8EZUgAAPBIq2" : {
    "bananas" : 150,
    "lastDayPlayed" : "2018-11-29",
    "longestStreak" : 1,
    "name" : "Jonathan Xiaodemon",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zdtY3H5wL6TIUnrc8EZUgAAPBIq2"
  },
  "ze0o6YA2dwM9ETD5Nlm6M7GfEOh1" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "ze0o6YA2dwM9ETD5Nlm6M7GfEOh1"
  },
  "ze69ZeQGFsbpiF4itrhR4sPS6At2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Thanht Aye",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "ze69ZeQGFsbpiF4itrhR4sPS6At2"
  },
  "zeXVlvonVMg3cU6YSjE1Z0fgMMc2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Einstein Express",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zeXVlvonVMg3cU6YSjE1Z0fgMMc2"
  },
  "zei1g8BWGGcpUrba51PQBhcpJTj1" : {
    "bananas" : 150,
    "lastDayPlayed" : "2018-12-18",
    "longestStreak" : 1,
    "name" : "Guilherme Ruaro",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zei1g8BWGGcpUrba51PQBhcpJTj1"
  },
  "zepJ8wD8lBaDAPxoFTYSihgi02j2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "苟飞",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zepJ8wD8lBaDAPxoFTYSihgi02j2"
  },
  "zeqISWrwIVPmG1dqQb1C8AfRF003" : {
    "bananas" : 400,
    "lastDayPlayed" : "2018-06-14",
    "longestStreak" : 1,
    "name" : "Jiyonggg",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zeqISWrwIVPmG1dqQb1C8AfRF003"
  },
  "zerlafxSljOcI1v0V8GRfZo6YzL2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Anjali Bothra",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zerlafxSljOcI1v0V8GRfZo6YzL2"
  },
  "zeyFYtQJxrN7aUbyervJ6dsVyav2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Stefan Holst",
    "stars" : 2,
    "subscribed" : false,
    "uid" : "zeyFYtQJxrN7aUbyervJ6dsVyav2"
  },
  "zezoLzFXW4RtQrwL7YW1lNbamra2" : {
    "bananas" : 150,
    "lastDayPlayed" : "2018-10-27",
    "longestStreak" : 1,
    "name" : "Daniel Ferrigato",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zezoLzFXW4RtQrwL7YW1lNbamra2"
  },
  "zfFtR7UEXcWxcmVH1iXnw1dGTBt1" : {
    "bananas" : 150,
    "lastDayPlayed" : "2018-04-28",
    "longestStreak" : 1,
    "name" : "Marc Huwyler",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zfFtR7UEXcWxcmVH1iXnw1dGTBt1"
  },
  "zfSlEgfjxMVpxMglLE1E6n5nckA2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Caz",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zfSlEgfjxMVpxMglLE1E6n5nckA2"
  },
  "zfVFzljQ9jX6dVJ28FM8EkC8IAg2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Juhyun Park",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zfVFzljQ9jX6dVJ28FM8EkC8IAg2"
  },
  "zfX5pLHUsUQyLSwnabZc1Oc0OHm2" : {
    "bananas" : 400,
    "lastDayPlayed" : "2018-12-03",
    "longestStreak" : 1,
    "name" : "",
    "stars" : 7,
    "subscribed" : false,
    "uid" : "zfX5pLHUsUQyLSwnabZc1Oc0OHm2"
  },
  "zfaMiy1mQubdryH0iJUvpGkF0MJ3" : {
    "bananas" : 600,
    "lastDayPlayed" : "2018-04-22",
    "longestStreak" : 1,
    "name" : "Nathan Smith",
    "stars" : 8,
    "subscribed" : false,
    "uid" : "zfaMiy1mQubdryH0iJUvpGkF0MJ3"
  },
  "zffgmofbCQeMIvbzD783dFL7NhC3" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Dafydd Williams",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zffgmofbCQeMIvbzD783dFL7NhC3"
  },
  "zfhA4TxCQvXvPYUGR2U6yifugHw2" : {
    "bananas" : 4200,
    "lastDayPlayed" : "2018-12-02",
    "longestStreak" : 2,
    "name" : "Ken Chan",
    "stars" : 23,
    "subscribed" : false,
    "uid" : "zfhA4TxCQvXvPYUGR2U6yifugHw2"
  },
  "zflVgD0XB6dgYXoMSE6nwuxJw2K2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Tin Lynn Myint",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zflVgD0XB6dgYXoMSE6nwuxJw2K2"
  },
  "zfwA2x8m3BgkLD8hGCw4pOshwHr1" : {
    "bananas" : 100,
    "lastDayPlayed" : "2018-05-06",
    "longestStreak" : 1,
    "name" : "Wang Chinrue",
    "stars" : 4,
    "subscribed" : false,
    "uid" : "zfwA2x8m3BgkLD8hGCw4pOshwHr1"
  },
  "zg7y12X3gCZeFfKGT4ixVxRhxKz2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Christoph Ulherr",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zg7y12X3gCZeFfKGT4ixVxRhxKz2"
  },
  "zgIlX1riWkbSXy35ApzlKq38XXY2" : {
    "bananas" : 550,
    "lastDayPlayed" : "2019-01-05",
    "longestStreak" : 2,
    "name" : "賴玫孜",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "zgIlX1riWkbSXy35ApzlKq38XXY2"
  },
  "zgSXndkNUOMPmB47uSO6OHTQLJe2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Danica Magadia",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zgSXndkNUOMPmB47uSO6OHTQLJe2"
  },
  "zgd3dQQcYoferMuzilX8OzPLiqG3" : {
    "bananas" : 2400,
    "lastDayPlayed" : "2018-11-28",
    "longestStreak" : 2,
    "name" : "Fab Ulousfab",
    "stars" : 11,
    "subscribed" : false,
    "uid" : "zgd3dQQcYoferMuzilX8OzPLiqG3"
  },
  "zghUw5XBDkNoGC25zsLObiLCQiZ2" : {
    "bananas" : 100,
    "lastDayPlayed" : "2018-03-23",
    "longestStreak" : 1,
    "name" : "Riham",
    "stars" : 4,
    "subscribed" : false,
    "uid" : "zghUw5XBDkNoGC25zsLObiLCQiZ2"
  },
  "zgjeBDbDyHO0XlGcF6p30THLr3h2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zgjeBDbDyHO0XlGcF6p30THLr3h2"
  },
  "zguCfZdFAwN7AFLK8lSx65TnXEy2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Angelina Guy",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zguCfZdFAwN7AFLK8lSx65TnXEy2"
  },
  "zhQxJ9631ATtN5vwFBd8ThlNJos1" : {
    "bananas" : 1100,
    "lastDayPlayed" : "2018-12-22",
    "longestStreak" : 2,
    "name" : "",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zhQxJ9631ATtN5vwFBd8ThlNJos1"
  },
  "zhb6AgcDqAeWfXImwGQyKrjSjJo2" : {
    "bananas" : 200,
    "lastDayPlayed" : "2018-09-29",
    "longestStreak" : 1,
    "name" : "Piki Dia",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "zhb6AgcDqAeWfXImwGQyKrjSjJo2"
  },
  "zhp1COgptLWv7yyJQ8Wn2oIWRb02" : {
    "bananas" : 1900,
    "lastDayPlayed" : "2018-07-12",
    "longestStreak" : 2,
    "name" : "Caity Denholm",
    "stars" : 10,
    "subscribed" : false,
    "uid" : "zhp1COgptLWv7yyJQ8Wn2oIWRb02"
  },
  "zhpbWXHulcYMkqySC2SQOnTnqf53" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "謝慧文",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zhpbWXHulcYMkqySC2SQOnTnqf53"
  },
  "zhx16l0A9lh8VjNJ1b5H7Dpi9GA2" : {
    "bananas" : 350,
    "lastDayPlayed" : "2018-11-09",
    "longestStreak" : 1,
    "name" : "Pretty Based 9000",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "zhx16l0A9lh8VjNJ1b5H7Dpi9GA2"
  },
  "zi0OhdhliafZSylhvLiOz3tpxDL2" : {
    "bananas" : 150,
    "lastDayPlayed" : "2018-10-10",
    "longestStreak" : 1,
    "name" : "Angela W.",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zi0OhdhliafZSylhvLiOz3tpxDL2"
  },
  "ziCLlrq6ALSubz9MyVtrZkxwXbg1" : {
    "bananas" : 1350,
    "lastDayPlayed" : "2018-05-11",
    "longestStreak" : 1,
    "name" : "Andrea Ossi-Perretta",
    "stars" : 10,
    "subscribed" : false,
    "uid" : "ziCLlrq6ALSubz9MyVtrZkxwXbg1"
  },
  "ziJwdb1qXgRI518161NcgjNfY0z2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Manuel Rozewski",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "ziJwdb1qXgRI518161NcgjNfY0z2"
  },
  "ziKxPXQKjmYYuPNexN9ch9ZN7ef2" : {
    "bananas" : 200,
    "lastDayPlayed" : "2018-10-04",
    "longestStreak" : 1,
    "name" : "Mikael Irfan",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "ziKxPXQKjmYYuPNexN9ch9ZN7ef2"
  },
  "ziRV3praVQT9BH3RuoHWzyEkdTD2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "ေကာင္းကင္ ယံ",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "ziRV3praVQT9BH3RuoHWzyEkdTD2"
  },
  "ziUZGpROeXaghHOn8Z0iI0LLnn52" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "최유진",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "ziUZGpROeXaghHOn8Z0iI0LLnn52"
  },
  "ziYVZtM5iLaLF8JURdCXHLj3Suq2" : {
    "bananas" : 100,
    "lastDayPlayed" : "2019-02-03",
    "longestStreak" : 1,
    "name" : "Sam Raja Aziz",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "ziYVZtM5iLaLF8JURdCXHLj3Suq2"
  },
  "zicfLMX5C0OtjMZbgX4jdzXw47f1" : {
    "bananas" : 1150,
    "lastDayPlayed" : "2018-12-07",
    "longestStreak" : 1,
    "name" : "Dereck Tello",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "zicfLMX5C0OtjMZbgX4jdzXw47f1"
  },
  "ziqiEG4pduRREXuKQ7pgDu7Wr4A3" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "cheah cheah",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "ziqiEG4pduRREXuKQ7pgDu7Wr4A3"
  },
  "zjAN0HjNNqZEFjF1u43OKdeubnD2" : {
    "bananas" : 150,
    "lastDayPlayed" : "2019-01-03",
    "longestStreak" : 1,
    "name" : "Maria Kristina Maralit",
    "stars" : 4,
    "subscribed" : false,
    "uid" : "zjAN0HjNNqZEFjF1u43OKdeubnD2"
  },
  "zjJL7cCWlqXso4M8qGfXIe4yYft2" : {
    "bananas" : 500,
    "lastDayPlayed" : "2018-08-27",
    "longestStreak" : 1,
    "name" : "Luis Villafranca",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zjJL7cCWlqXso4M8qGfXIe4yYft2"
  },
  "zjZLUOKZslZntrQF66vGTTXlr7o2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "RJ Tagalog",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zjZLUOKZslZntrQF66vGTTXlr7o2"
  },
  "zjd8z8kuigRagSiKcBXNF0JvdYf1" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Torren Alexander",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zjd8z8kuigRagSiKcBXNF0JvdYf1"
  },
  "zje4fPFNhaPJCtXHEDltLl5Xpcj2" : {
    "bananas" : 2600,
    "lastDayPlayed" : "2019-01-18",
    "longestStreak" : 2,
    "name" : "Diyanah Nisa",
    "stars" : 15,
    "subscribed" : false,
    "uid" : "zje4fPFNhaPJCtXHEDltLl5Xpcj2"
  },
  "zjquqEfwXeauT2dMCedo6XQW75p2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Winrich Arndt",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zjquqEfwXeauT2dMCedo6XQW75p2"
  },
  "zjxnn7HsyZWFCy86PRo00UT4zfu1" : {
    "bananas" : 1200,
    "lastDayPlayed" : "2019-01-14",
    "longestStreak" : 1,
    "name" : "Felipe Lima",
    "stars" : 10,
    "subscribed" : false,
    "uid" : "zjxnn7HsyZWFCy86PRo00UT4zfu1"
  },
  "zjzDEbCknnXATdyJXyp6ahBiZkB3" : {
    "bananas" : 200,
    "lastDayPlayed" : "2018-11-20",
    "longestStreak" : 1,
    "name" : "김 태 형",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "zjzDEbCknnXATdyJXyp6ahBiZkB3"
  },
  "zk0M2P1myzZnCHDNw39BM59DpFq2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Louis Laguna",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zk0M2P1myzZnCHDNw39BM59DpFq2"
  },
  "zk40ProwloTXGxOvcCn7DJWHxTk2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Teresa Tayu",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zk40ProwloTXGxOvcCn7DJWHxTk2"
  },
  "zk7xiooSrIPrBSXmChsbgGt5HXC2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "張子光",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zk7xiooSrIPrBSXmChsbgGt5HXC2"
  },
  "zkU5knOHImOZiWG1AMIgyEqYqjN2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Yi Lin Li",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zkU5knOHImOZiWG1AMIgyEqYqjN2"
  },
  "zkZl5d60Z4a7RYFN51bU80LkbZ63" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Canitah McArthur",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zkZl5d60Z4a7RYFN51bU80LkbZ63"
  },
  "zkovxRxhlMQHC3IcteBvm4qXZPn1" : {
    "bananas" : 1550,
    "lastDayPlayed" : "2018-09-14",
    "longestStreak" : 1,
    "name" : "Kendrick Tan",
    "stars" : 8,
    "subscribed" : false,
    "uid" : "zkovxRxhlMQHC3IcteBvm4qXZPn1"
  },
  "zkwzh8XrEMh6CQOoCGMCs2z1J372" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Mads R",
    "stars" : 4,
    "subscribed" : false,
    "uid" : "zkwzh8XrEMh6CQOoCGMCs2z1J372"
  },
  "zl2BSyGz5oeBTTTD4hJRyDKGEOD2" : {
    "bananas" : 200,
    "lastDayPlayed" : "2018-10-09",
    "longestStreak" : 1,
    "name" : "Chelsea Milam",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "zl2BSyGz5oeBTTTD4hJRyDKGEOD2"
  },
  "zl3hLLmlCqdkk2JJAsZBy8J8Pl13" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Shannon Mcknight",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zl3hLLmlCqdkk2JJAsZBy8J8Pl13"
  },
  "zlQonVJMyody3h4XjgCm1HsoVL63" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Rach Liaw",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zlQonVJMyody3h4XjgCm1HsoVL63"
  },
  "zlS3xq5m8SMHLGZ9A3Gv8iepbxn1" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Victoria Phongpaew",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zlS3xq5m8SMHLGZ9A3Gv8iepbxn1"
  },
  "zlng6RVpGzcafm3jYRlS7C35zYx2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "孙岩",
    "stars" : 0,
    "subscribed" : false,
    "uid" : "zlng6RVpGzcafm3jYRlS7C35zYx2"
  },
  "zlu1B1NCJSUHYb6dojcKrJ8qRAv2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "David Bailey",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zlu1B1NCJSUHYb6dojcKrJ8qRAv2"
  },
  "zm9pePeyfmfqMm4nIY8WzpaPrJQ2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Jamz",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zm9pePeyfmfqMm4nIY8WzpaPrJQ2"
  },
  "zmBkTZWmccWbHoPq2yVyNf4VGLE3" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Thomas Beritault",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zmBkTZWmccWbHoPq2yVyNf4VGLE3"
  },
  "zmMvBdJ1EZgjOw2IXFzIPZcXiIE3" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Gustavo Angel Cortez Garcia",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zmMvBdJ1EZgjOw2IXFzIPZcXiIE3"
  },
  "zmULVDDBUEfYKwa4zsecyPjCRBn1" : {
    "bananas" : 350,
    "lastDayPlayed" : "2018-10-23",
    "longestStreak" : 1,
    "name" : "Alpesh Rathod",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "zmULVDDBUEfYKwa4zsecyPjCRBn1"
  },
  "zmcC10SkIPR9YhDxGLthjWS3yzM2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "prerana Joshi",
    "stars" : 4,
    "subscribed" : false,
    "uid" : "zmcC10SkIPR9YhDxGLthjWS3yzM2"
  },
  "zmeCux9FgvS92S4bVS6YG8rPdOP2" : {
    "bananas" : 350,
    "lastDayPlayed" : "2018-09-24",
    "longestStreak" : 1,
    "name" : "Eric Pargeon",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "zmeCux9FgvS92S4bVS6YG8rPdOP2"
  },
  "zmg2bCr6goagMs5MoPACa9DF1mx1" : {
    "bananas" : 150,
    "lastDayPlayed" : "2018-07-18",
    "longestStreak" : 1,
    "name" : "Owen Toh",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zmg2bCr6goagMs5MoPACa9DF1mx1"
  },
  "zmjfBe4ET9VoA58OhhfgINFdb1J2" : {
    "bananas" : 1900,
    "lastDayPlayed" : "2019-02-02",
    "longestStreak" : 2,
    "name" : "",
    "stars" : 13,
    "subscribed" : false,
    "uid" : "zmjfBe4ET9VoA58OhhfgINFdb1J2"
  },
  "znGidINUdmMCFTJ8qq2k0mlyNhe2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Aneta Držmíšková",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "znGidINUdmMCFTJ8qq2k0mlyNhe2"
  },
  "znHBpuZTcVhC5DpMtSAYLGtWo023" : {
    "bananas" : 14300,
    "lastDayPlayed" : "2018-05-15",
    "longestStreak" : 3,
    "name" : "Tobias Fager",
    "stars" : 64,
    "subscribed" : false,
    "uid" : "znHBpuZTcVhC5DpMtSAYLGtWo023"
  },
  "znN28vsazbRuBtED8bMUTk1pYhk2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Tasha NC",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "znN28vsazbRuBtED8bMUTk1pYhk2"
  },
  "znbr0DbjTBhUmp2zjZTtfdZ1yTZ2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Shijie Liu",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "znbr0DbjTBhUmp2zjZTtfdZ1yTZ2"
  },
  "znrWTygtGSS9JG4YqLGkM7dsFeO2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Vance Lee",
    "stars" : 4,
    "subscribed" : false,
    "uid" : "znrWTygtGSS9JG4YqLGkM7dsFeO2"
  },
  "zo817DytcKaRLyhf9W50ZwvTqLI3" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "黎碧良",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zo817DytcKaRLyhf9W50ZwvTqLI3"
  },
  "zoMFxkCEjuRNLZzxEobKzIdozQ32" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Fon Chen Wenyu",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zoMFxkCEjuRNLZzxEobKzIdozQ32"
  },
  "zoWgSNiXriPiHs7NxbpH3qVp2wf1" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Christian Grohmann",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zoWgSNiXriPiHs7NxbpH3qVp2wf1"
  },
  "zoXxyJIWNdQjX22aJB4ImHzYX4u2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zoXxyJIWNdQjX22aJB4ImHzYX4u2"
  },
  "zon4JUaO72T7mqAcP7GZagDytpW2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Brice Tietavani",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zon4JUaO72T7mqAcP7GZagDytpW2"
  },
  "zoo7doG8i2PbnjVnCL7fFbaGwLX2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "mike",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zoo7doG8i2PbnjVnCL7fFbaGwLX2"
  },
  "zooBXnTUXHeRDEMpYV4ET8FjUzy2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "林汶柏",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zooBXnTUXHeRDEMpYV4ET8FjUzy2"
  },
  "zossN80tq5afp5NXSdcUovvNwma2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Nik",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zossN80tq5afp5NXSdcUovvNwma2"
  },
  "zotuTYo21HM8I3SXPKBmuXq1FpR2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Pang Le Yi",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zotuTYo21HM8I3SXPKBmuXq1FpR2"
  },
  "zp8pWp168ZYv3XqbGBIAn9PqnlJ3" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "SAMFM52 GAMING",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zp8pWp168ZYv3XqbGBIAn9PqnlJ3"
  },
  "zpBoeaiiHrWCYkDbYD09jlDCzZl2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Francesca Pia",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zpBoeaiiHrWCYkDbYD09jlDCzZl2"
  },
  "zpGPokVHI0PWglXELkJXCj1FsJI3" : {
    "bananas" : 1750,
    "lastDayPlayed" : "2018-11-02",
    "longestStreak" : 2,
    "name" : "",
    "stars" : 13,
    "subscribed" : false,
    "uid" : "zpGPokVHI0PWglXELkJXCj1FsJI3"
  },
  "zpHyPyLVbfNLQLs42VcTTbDao0q2" : {
    "bananas" : 750,
    "lastDayPlayed" : "2018-06-23",
    "longestStreak" : 1,
    "name" : "yellowsawee",
    "stars" : 7,
    "subscribed" : false,
    "uid" : "zpHyPyLVbfNLQLs42VcTTbDao0q2"
  },
  "zpJoxpEhNsZar00M5xAURmJNv0a2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Gc Liew",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zpJoxpEhNsZar00M5xAURmJNv0a2"
  },
  "zpSxoVnPWJfcO1jC5LV0E4hknun2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Allen Toh",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zpSxoVnPWJfcO1jC5LV0E4hknun2"
  },
  "zpXcQba5XuYnfL7EZ7tj0kTIop13" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Lulissa Elisska",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zpXcQba5XuYnfL7EZ7tj0kTIop13"
  },
  "zphE5Hyx0BULI7wAxyUcM39NGkh2" : {
    "bananas" : 750,
    "lastDayPlayed" : "2018-12-09",
    "longestStreak" : 1,
    "name" : "Kieron Halliday",
    "stars" : 8,
    "subscribed" : false,
    "uid" : "zphE5Hyx0BULI7wAxyUcM39NGkh2"
  },
  "zpmrsmA8QOTovmvQb1HkOanPjBD2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Kamil Knodel",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zpmrsmA8QOTovmvQb1HkOanPjBD2"
  },
  "zq76SXOnbFOAvZpD4ExU01hHbv12" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Azamshah Islah",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zq76SXOnbFOAvZpD4ExU01hHbv12"
  },
  "zqJpqWuTjqeNrP7ICYSf2EJwg9o1" : {
    "bananas" : 400,
    "lastDayPlayed" : "2018-07-21",
    "longestStreak" : 1,
    "name" : "",
    "stars" : 7,
    "subscribed" : false,
    "uid" : "zqJpqWuTjqeNrP7ICYSf2EJwg9o1"
  },
  "zqbRQv9U3JVa4w9eisW4C6unycy2" : {
    "bananas" : 300,
    "lastDayPlayed" : "2018-10-23",
    "longestStreak" : 1,
    "name" : "Eve Haumschild",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zqbRQv9U3JVa4w9eisW4C6unycy2"
  },
  "zqgAtUaWwCU4S0WqQEieyStZgP83" : {
    "bananas" : 600,
    "lastDayPlayed" : "2018-08-20",
    "longestStreak" : 1,
    "name" : "Alexander Digholm",
    "stars" : 7,
    "subscribed" : false,
    "uid" : "zqgAtUaWwCU4S0WqQEieyStZgP83"
  },
  "zqi2f2g8rKaRPn3bbPrDgm7pLCo1" : {
    "bananas" : 550,
    "lastDayPlayed" : "2019-01-30",
    "longestStreak" : 1,
    "name" : "Ботагоз Сексембаева",
    "stars" : 7,
    "subscribed" : false,
    "uid" : "zqi2f2g8rKaRPn3bbPrDgm7pLCo1"
  },
  "zqjY0JXMm0QZglpVzOps30TH3mr2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Rowan Engelbregt",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zqjY0JXMm0QZglpVzOps30TH3mr2"
  },
  "zqlGtSDtRCf1WYD7S6OcWJJZtrI2" : {
    "bananas" : 750,
    "lastDayPlayed" : "2019-01-14",
    "longestStreak" : 3,
    "name" : "Adam Koh",
    "stars" : 7,
    "subscribed" : false,
    "uid" : "zqlGtSDtRCf1WYD7S6OcWJJZtrI2"
  },
  "zqr9abaBdqadzw5ADyWpFKUYUU93" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Orx Icx",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zqr9abaBdqadzw5ADyWpFKUYUU93"
  },
  "zrE2VTrOg5SZpkaKOx9T3eutLqc2" : {
    "bananas" : 200,
    "lastDayPlayed" : "2018-03-31",
    "longestStreak" : 1,
    "name" : "Sylvester Sabastian",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "zrE2VTrOg5SZpkaKOx9T3eutLqc2"
  },
  "zrPeBbET8jWcbxPOzXiIZ3gFezE3" : {
    "bananas" : 3550,
    "lastDayPlayed" : "2019-01-28",
    "longestStreak" : 1,
    "name" : "Chaiya Vomschee",
    "stars" : 14,
    "subscribed" : false,
    "uid" : "zrPeBbET8jWcbxPOzXiIZ3gFezE3"
  },
  "zrT6eQjZsNPUzfzjqN2JFOAaxUr2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Louise Soriano",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zrT6eQjZsNPUzfzjqN2JFOAaxUr2"
  },
  "zrghPITD6tZPSgWQmaxjzPCMdVz2" : {
    "bananas" : 2350,
    "lastDayPlayed" : "2019-02-01",
    "longestStreak" : 2,
    "name" : "Safwan Fatih",
    "stars" : 16,
    "subscribed" : false,
    "uid" : "zrghPITD6tZPSgWQmaxjzPCMdVz2"
  },
  "zriukx06jaWmRiyxHfbMYIpoC963" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Neil Dickinson",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zriukx06jaWmRiyxHfbMYIpoC963"
  },
  "zs01Cho02IYllyoXyaskLHYaksu2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Yirou Teoh",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zs01Cho02IYllyoXyaskLHYaksu2"
  },
  "zsMVKB5bAhelzmGq0Q35nV4vKlQ2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Sulia Shaedin",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zsMVKB5bAhelzmGq0Q35nV4vKlQ2"
  },
  "zsRe73zITOWtuyrr41SiYxrr7SY2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "有为",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zsRe73zITOWtuyrr41SiYxrr7SY2"
  },
  "zsYo8n58DjOfCNG01ZSqfzBvKL42" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zsYo8n58DjOfCNG01ZSqfzBvKL42"
  },
  "zszTz04D6ObZyyGsTiA0Gjj23k22" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Adryelle Coelho",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zszTz04D6ObZyyGsTiA0Gjj23k22"
  },
  "ztZ5ULy0M2dYQrIq5In51CwreMT2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Zikrul Ameen",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "ztZ5ULy0M2dYQrIq5In51CwreMT2"
  },
  "ztZKUHJbP6Qom8OkpIYJmgxAneB3" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "谢雪妮",
    "stars" : 4,
    "subscribed" : false,
    "uid" : "ztZKUHJbP6Qom8OkpIYJmgxAneB3"
  },
  "ztnyIglceFe79TtypXUZHZAenHg2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Dylan Alexander",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "ztnyIglceFe79TtypXUZHZAenHg2"
  },
  "zttAQVgVvcdJBOnDBlsHbK9VWB33" : {
    "bananas" : 900,
    "lastDayPlayed" : "2018-05-07",
    "longestStreak" : 1,
    "name" : "Kimberlie",
    "stars" : 8,
    "subscribed" : false,
    "uid" : "zttAQVgVvcdJBOnDBlsHbK9VWB33"
  },
  "zu11Y3y2kjcc9Xo1XfpDmKp3lWc2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Jennalyn Delacruz",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zu11Y3y2kjcc9Xo1XfpDmKp3lWc2"
  },
  "zu27CAM0lVdQInZ2sjkL0hkPDyJ3" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Sandeep Rawson",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zu27CAM0lVdQInZ2sjkL0hkPDyJ3"
  },
  "zuHgvZULlXe6EJABD3aveXq5QSE2" : {
    "bananas" : 3150,
    "lastDayPlayed" : "2018-10-29",
    "longestStreak" : 3,
    "name" : "Ruthie Duncan",
    "stars" : 16,
    "subscribed" : true,
    "uid" : "zuHgvZULlXe6EJABD3aveXq5QSE2"
  },
  "zuYGg0IfogWMYnPv1hSVhA5rhCI3" : {
    "bananas" : 400,
    "lastDayPlayed" : "2018-06-24",
    "longestStreak" : 1,
    "name" : "Josh Stasi",
    "stars" : 7,
    "subscribed" : false,
    "uid" : "zuYGg0IfogWMYnPv1hSVhA5rhCI3"
  },
  "zuifsow2I4T7vUhgi1zNr7AXXwy1" : {
    "bananas" : 400,
    "lastDayPlayed" : "2018-08-09",
    "longestStreak" : 2,
    "name" : "李先生",
    "stars" : 7,
    "subscribed" : false,
    "uid" : "zuifsow2I4T7vUhgi1zNr7AXXwy1"
  },
  "zuubU1DDYzVCQvpWGjFErDExKP13" : {
    "bananas" : 400,
    "lastDayPlayed" : "2018-08-28",
    "longestStreak" : 1,
    "name" : "tasja larsen",
    "stars" : 7,
    "subscribed" : false,
    "uid" : "zuubU1DDYzVCQvpWGjFErDExKP13"
  },
  "zv708TiAHEPeSqA7W4PTlFDlfKq1" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Joseph Rand Hilario",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zv708TiAHEPeSqA7W4PTlFDlfKq1"
  },
  "zvgKhoJMW6NwTRSUK3ie3yaiH9C2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Sanong Thipsa Thian",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zvgKhoJMW6NwTRSUK3ie3yaiH9C2"
  },
  "zwMh4FTYvEbOHVDTjCqnh4KRX1T2" : {
    "bananas" : 350,
    "lastDayPlayed" : "2018-11-12",
    "longestStreak" : 1,
    "name" : "Teddy",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zwMh4FTYvEbOHVDTjCqnh4KRX1T2"
  },
  "zxIstmzEt4ZKs3ggR5BzRl7RSB43" : {
    "bananas" : 200,
    "lastDayPlayed" : "2018-06-29",
    "longestStreak" : 1,
    "name" : "김문희",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "zxIstmzEt4ZKs3ggR5BzRl7RSB43"
  },
  "zxNTlWI9TrWuHZiHvmFugGjPfZH3" : {
    "bananas" : 350,
    "lastDayPlayed" : "2018-11-01",
    "longestStreak" : 1,
    "name" : "Jasmine Zaini",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "zxNTlWI9TrWuHZiHvmFugGjPfZH3"
  },
  "zxNqVrLoJJOif2oHv2RUpw9nSdq1" : {
    "bananas" : 1050,
    "lastDayPlayed" : "2018-06-30",
    "longestStreak" : 1,
    "name" : "Theng Theng",
    "stars" : 9,
    "subscribed" : false,
    "uid" : "zxNqVrLoJJOif2oHv2RUpw9nSdq1"
  },
  "zxYQWVjG0lVofYMq7E6YHv2rOOx1" : {
    "bananas" : 6050,
    "lastDayPlayed" : "2019-02-10",
    "longestStreak" : 2,
    "name" : "Paula Nicholson",
    "stars" : 26,
    "subscribed" : false,
    "uid" : "zxYQWVjG0lVofYMq7E6YHv2rOOx1"
  },
  "zxbkdkfuUKVbmQJlQfrX1K0XupD3" : {
    "bananas" : 500,
    "lastDayPlayed" : "2018-10-15",
    "longestStreak" : 1,
    "name" : "Patrick Meyer",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zxbkdkfuUKVbmQJlQfrX1K0XupD3"
  },
  "zxgmxNuBpXVTqey26SiYBfB6K7v1" : {
    "bananas" : 350,
    "lastDayPlayed" : "2019-01-15",
    "longestStreak" : 1,
    "name" : "",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "zxgmxNuBpXVTqey26SiYBfB6K7v1"
  },
  "zxof7OzVwmNTBX960gsiIhAWsBA3" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Xiao Qii",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zxof7OzVwmNTBX960gsiIhAWsBA3"
  },
  "zxtxBkJPtXaNnfithxer7rczOS72" : {
    "bananas" : 2450,
    "lastDayPlayed" : "2018-12-31",
    "longestStreak" : 1,
    "name" : "方景",
    "stars" : 16,
    "subscribed" : false,
    "uid" : "zxtxBkJPtXaNnfithxer7rczOS72"
  },
  "zy1c35c5QOeq5ibFExqdBxu1Z8x2" : {
    "bananas" : 2700,
    "lastDayPlayed" : "2018-12-16",
    "longestStreak" : 3,
    "name" : "",
    "stars" : 17,
    "subscribed" : false,
    "uid" : "zy1c35c5QOeq5ibFExqdBxu1Z8x2"
  },
  "zy3K9D3dZnR7H0Vzq2GD2ZbD2PV2" : {
    "bananas" : 2050,
    "lastDayPlayed" : "2019-02-10",
    "longestStreak" : 2,
    "name" : "",
    "stars" : 12,
    "subscribed" : false,
    "uid" : "zy3K9D3dZnR7H0Vzq2GD2ZbD2PV2"
  },
  "zy5Fy0QKFgS7sPwMsrqbjKudqe52" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Siti Rahmah",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zy5Fy0QKFgS7sPwMsrqbjKudqe52"
  },
  "zyLlXcrvtIVIbUXDpJJcgPKgyI92" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "谭浩",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zyLlXcrvtIVIbUXDpJJcgPKgyI92"
  },
  "zyQas9lZgBePwCA1fAowPMGlxU72" : {
    "bananas" : 1700,
    "lastDayPlayed" : "2019-01-22",
    "longestStreak" : 1,
    "name" : "Lia Yuliana Novita",
    "stars" : 12,
    "subscribed" : false,
    "uid" : "zyQas9lZgBePwCA1fAowPMGlxU72"
  },
  "zyQsd5Jv5LUgeVNqJjPIHsRpV1c2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Erke",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zyQsd5Jv5LUgeVNqJjPIHsRpV1c2"
  },
  "zycLGDOMWLZLyjGrc98TdumJHl32" : {
    "bananas" : 4600,
    "lastDayPlayed" : "2018-04-18",
    "longestStreak" : 4,
    "name" : "Ivy",
    "stars" : 21,
    "subscribed" : false,
    "uid" : "zycLGDOMWLZLyjGrc98TdumJHl32"
  },
  "zymjIEV0I8QrReMnh12JGR8pGqJ2" : {
    "bananas" : 0,
    "lastDayPlayed" : "2017-11-01",
    "longestStreak" : 0,
    "name" : "Andrew Semakin",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zymjIEV0I8QrReMnh12JGR8pGqJ2"
  },
  "zyqWz9Obwsfk9TIkDAoNshMGPtc2" : {
    "bananas" : 17200,
    "lastDayPlayed" : "2018-12-14",
    "longestStreak" : 4,
    "name" : "Kim Schytt-Nielsen ",
    "stars" : 35,
    "subscribed" : true,
    "uid" : "zyqWz9Obwsfk9TIkDAoNshMGPtc2"
  },
  "zysMpJUIpYepb1n3wELJajboTFE2" : {
    "bananas" : 400,
    "lastDayPlayed" : "2018-08-20",
    "longestStreak" : 1,
    "name" : "",
    "stars" : 7,
    "subscribed" : false,
    "uid" : "zysMpJUIpYepb1n3wELJajboTFE2"
  },
  "zywwDpX4ovUw52Kt2vOP6tFbpzG3" : {
    "bananas" : 3150,
    "lastDayPlayed" : "2018-10-22",
    "longestStreak" : 2,
    "name" : "Mohamad R Julian Wangsadinata",
    "stars" : 17,
    "subscribed" : false,
    "uid" : "zywwDpX4ovUw52Kt2vOP6tFbpzG3"
  },
  "zz3PO3lfXzQAx12HilVxkPrgcP63" : {
    "bananas" : 3200,
    "lastDayPlayed" : "2018-10-27",
    "longestStreak" : 1,
    "name" : "Luana Souza",
    "stars" : 13,
    "subscribed" : false,
    "uid" : "zz3PO3lfXzQAx12HilVxkPrgcP63"
  },
  "zzEUwf7BeTXL628IuQdfCw4zdAk2" : {
    "bananas" : 150,
    "lastDayPlayed" : "2018-10-27",
    "longestStreak" : 1,
    "name" : "陳潔瑩",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zzEUwf7BeTXL628IuQdfCw4zdAk2"
  },
  "zzqGU2sWryUPwRfqUphPprnK1gs2" : {
    "bananas" : 200,
    "lastDayPlayed" : "2018-04-26",
    "longestStreak" : 1,
    "name" : "Ryden Shipper",
    "stars" : 6,
    "subscribed" : false,
    "uid" : "zzqGU2sWryUPwRfqUphPprnK1gs2"
  },
  "zzupAnHefmYqyPM9Sx74j88aeZB2" : {
    "bananas" : 200,
    "lastDayPlayed" : "2018-07-04",
    "longestStreak" : 1,
    "name" : "Jamie Hatton",
    "stars" : 5,
    "subscribed" : false,
    "uid" : "zzupAnHefmYqyPM9Sx74j88aeZB2"
  },
  "zzvyAcTpYdUsL5S2SgwayV1ugOE2" : {
    "bananas" : 400,
    "lastDayPlayed" : "2018-10-28",
    "longestStreak" : 1,
    "name" : "Josias Lopes",
    "stars" : 7,
    "subscribed" : false,
    "uid" : "zzvyAcTpYdUsL5S2SgwayV1ugOE2"
  }
}
;
export default initialData;